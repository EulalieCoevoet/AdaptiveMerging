Hi! 
I believe I did questions 1 2 and 3 correctly.

My code for 4 seems to be very buggy. When I load hf1.ele and pin the top 2 corners... it looks like it might be okay, with cracks appearing where they are expected... 
but any agitation at all causes the system to crack and explode.

I've tried very hard to find the root of this bug but couldn't and ran out of time and honestly had spent 
way too much on it. 
I would like to receive partial points on this however, so let me explain what I did:
I gave each FEMTriangle a new Vector2d attribute: centre, which holds the coordinates for the centre of each triangle.
I also modified the Particle class by adding a largestEigenvalue and corresponding Eigenvector attributes.
I then made Particle class extend the comparable interface. This way I can sort all the particles
according to their eigenvalues in the system easily with a function like Collections.sort(particle_list).
I would then have a priority queue of particles to collapse.

This would have proved useful when I would have gotten to hinge joints and been more picky about the particles i collide.
In any case i got the highest Evalue in the system, went to that particle, looped through all that particles triangles,
created a vector between the particle and the centre of each triangle, dotted that with the eigen vector, if that 
is positive, this belongs to a new DOF.
I create a new DOF, add all appropriate triangles to that, and as I do, remove them from the old DOF, at the same time
I modify the new triangle's vertices Ai, Bi, Ci using the addTriangle function.

Next I go through all the old triangles and remove all the appropriate indexes from fminus and fplus, and attempt to 
modify the old Vertex triangle's Ai, Bi, Ci's.

I don't really know what I'm doing wrong, and I understand you can't give me full marks, but I really hope I can get some extra
part marks for this.

The code as it is now is buggy, to get rid of the bugs, comment out the contents of processfracture()!!
