package comp559.pdcontrol;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

import org.ode4j.math.DVector3;
import org.ode4j.ode.DBody;
import org.ode4j.ode.DContact;
import org.ode4j.ode.DContactBuffer;
import org.ode4j.ode.DContactJoint;
import org.ode4j.ode.DGeom;
import org.ode4j.ode.DGeom.DNearCallback;
import org.ode4j.ode.DJoint.DJointFeedback;
import org.ode4j.ode.DJointGroup;
import org.ode4j.ode.DSpace;
import org.ode4j.ode.DWorld;
import org.ode4j.ode.OdeHelper;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;

import mintools.parameters.BooleanParameter;
import mintools.parameters.DoubleParameter;
import mintools.parameters.IntParameter;
import mintools.swing.CollapsiblePanel;
import mintools.swing.VerticalFlowPanel;
import mintools.viewer.BoxRoom;
import mintools.viewer.FancyArrow;

/**
 * Simulation class that manages various elements in the simulated scene,
 * deals with creating the walls and the floor, and deals with stepping the 
 * simulation, collision detection and contact.
 * @author kry
 */
public class ODESimulation {

    /** The ODE simulated world */
    public DWorld world;
    
    /** The space used for collision detection */
    public DSpace space;
    
    private DJointGroup contactgroup;
    
    private Set<DBody> nonCollidable = new HashSet<DBody>();

    ArrayList<Skeleton> skeletons = new ArrayList<Skeleton>();
    
    MouseSpring mouseSpring = new MouseSpring();
    
    /** Step size of the simulation */
    public DoubleParameter stepSize = new DoubleParameter( "step size", 0.02, 1e-4, 0.1 );
    
    // NOTE that many substeps are typically necessary for ODE to produce good results for a skeletal simulation
    private IntParameter subSteps = new IntParameter( "substeps", 100, 1, 1000 );    
    
    private BooleanParameter enableGravity = new BooleanParameter( "enable gravity", true );
    private DoubleParameter gravity = new DoubleParameter( "gravity", -9.8, -20, 20 );
    
    
    private DoubleParameter stringSlack = new DoubleParameter( "marionette string slackness", 0, 0, 1 );

    public BooleanParameter useMarionetteSprings = new BooleanParameter("use marionette springs", true );
    private DoubleParameter stringLength = new DoubleParameter( "marionette string length", 5, 0, 10 );
    private DoubleParameter stiffness = new DoubleParameter( "marionette spring Stiffness", 1, 0, 5 );
    private DoubleParameter damping = new DoubleParameter( "marionette spring Damping", 1, 0, 2 );
    
    // TODO: (Objective 2) Consider changing the default value after completing objective 2 and 3
    private BooleanParameter enableContacts = new BooleanParameter( "enable self contact (except betwen adjacent bodies)", true );
    private DoubleParameter friction = new DoubleParameter( "friction coefficient", 0.33, 0, 2 );
    
    private BooleanParameter drawContacts = new BooleanParameter( "draw contacts", false );
    private DoubleParameter contactForceScale = new DoubleParameter( "contact force scale (viz)", 1, 0.1, 10);
    
    private BoxRoom boxRoom = new BoxRoom();
    
    List<Projectile> projectiles = new ArrayList<Projectile>();

    /**
     * @return a control panel for adjusting simulation and viewing parameters
     */
    public JPanel getControls() {
        VerticalFlowPanel vfp = new VerticalFlowPanel();
        vfp.setBorder(new TitledBorder("Open Dynamics Simulation Controls"));
        vfp.add( stepSize.getSliderControls(true) );
        vfp.add( subSteps.getSliderControls() );

        vfp.add( enableGravity.getControls() );
        vfp.add( gravity.getSliderControls(false));
        vfp.add( enableContacts.getControls() );
        vfp.add( drawContacts.getControls() );
        vfp.add( contactForceScale.getSliderControls(true) );
        vfp.add( friction.getSliderControls(false) );
        vfp.add( useMarionetteSprings.getControls() );
        vfp.add( stiffness.getSliderControls(false) );
        vfp.add( damping.getSliderControls(false) );
        vfp.add( stringLength.getSliderControls(false) );
        vfp.add( stringSlack.getSliderControls(false) );
        
        vfp.add( Skeleton.getControls() );
        
        CollapsiblePanel cp = new CollapsiblePanel( vfp.getPanel() );
        return cp;
    }
    
    /**
     * An amount to lower the floor so that the feet of the character defined in the bvh 
     * are not below the floor to start
     */
    public double floorOffset = -0.025;// 0.06;//-0.025;
    
    /**
     * Creates the world for ODE and initializes objects.
     */
    public ODESimulation() {
        OdeHelper.initODE2(0);
        world = OdeHelper.createWorld();
        space = OdeHelper.createHashSpace(null);
        contactgroup = OdeHelper.createJointGroup();

        // create a floor and four walls
        OdeHelper.createPlane (space, 0, 1, 0,  floorOffset);
        OdeHelper.createPlane (space, 1, 0, 0, -4);
        OdeHelper.createPlane (space,-1, 0, 0, -4);
        OdeHelper.createPlane (space, 0, 0,-1, -4);
        OdeHelper.createPlane (space, 0, 0, 1, -4);

        boxRoom.setBoundingBox( new Vector3d( -4, floorOffset, -4), new Vector3d( 4, 8, 4) );        
    }

    /**
     * Adds a skeleton to the list of simulated skeletons
     * @param skeleton
     */
    public void addSkeleton( Skeleton skeleton ) {
        skeletons.add( skeleton );
        nonCollidable.addAll( skeleton.nonCollidable );
    }
    
    /**
     * Cleans up ODE objects.  Call this if you wish to discard this ODESimulation.
     */
    public void cleanup() {
        contactgroup.destroy();
        space.destroy();
        world.destroy();
        OdeHelper.closeODE();
    }
        
    /**
     * Displays the objects in the ODE simulation in their current positions
     * @param drawable
     */
    public void display( GLAutoDrawable drawable ) {
        GL2 gl = drawable.getGL().getGL2();
        
        boxRoom.display(drawable);
        for ( Projectile p : projectiles ) {
        	p.display( drawable );
        }
        for ( Skeleton s : skeletons ) {
            s.display( drawable );
        }
        
        // draw the contacts
        final FancyArrow fa = new FancyArrow();
        fa.setSize(0.025);
        if ( drawContacts.getValue() ) {
	        for ( ContactPair cp : L ) {
	        	final Point3d pos = new Point3d();
	        	final Vector3d f = new Vector3d();
	        	ODETools.setVecmathFromODE( pos, cp.contact.getContactGeom().pos );
	        	ODETools.setVecmathFromODE( f, cp.fb.f1 );
	        	final Point3d to = new Point3d();
	        	f.scale( contactForceScale.getValue() );
	        	to.add( pos, f );
	        	fa.setFrom( pos );
	        	fa.setTo( to );
	        	fa.draw(gl);
	        }
        }
    }
    
    public void displayNonShadowable( GLAutoDrawable drawable ) {
    	if ( useMarionetteSprings.getValue() ) {
	        for ( Skeleton s : skeletons ) {
	            s.displayMarrionetteSprings( drawable );
	        }
    	}
    }
    
    public void throwProjectile( ) {
        Projectile p = new Projectile( world, space );
    	projectiles.add( p );
    }
    
    public void clearProjectiles() {
        for ( Projectile p : projectiles ) {
        	p.destroy();
        }  
        projectiles.clear();
    }
    
    /**
     * Sets the position and velocity of objects in the scene
     */
    private void setInitialObjectPositions() {     
        for ( Skeleton s : skeletons ) {
            s.reset();
        }               
    }
    
    private double elapsed = 0;
   
    /**
     * Steps the simulation ahead.
     */
    public void step() {
        int ss = subSteps.getValue();
        double h = stepSize.getValue() / ss;
        DVector3 g = new DVector3( 0, enableGravity.getValue() ? gravity.getValue() : 0, 0 );
        world.setGravity(g);
        for ( int i = 0; i < ss; i++ ) {  
            L.clear();
            space.collide( 0, myNearCallback );

            for ( Skeleton s : skeletons ) {
                s.applyJointTorques();
            }

            world.quickStep(h); // world.step(h); // non quick step not reliable?
            elapsed += h;
            
            MouseSpring.k = stiffness.getValue();
            MouseSpring.c = damping.getValue();
            mouseSpring.apply();
            
            if ( useMarionetteSprings.getValue() ) {
	            for ( Skeleton s : skeletons ) {
	            	s.updateSprings();
	                MarionetteSpring.k = stiffness.getValue();
	                MarionetteSpring.c = damping.getValue();
	                MarionetteSpring.l0 = stringLength.getValue();
	                MarionetteSpring.slacknessRatio = stringSlack.getValue();
	                s.applySprings();
	            }
            }
            
            contactgroup.empty();
        }
    }   

    /**
     * Resets the simulation to its initial configuration
     */
    public void reset() {
        setInitialObjectPositions();
        elapsed = 0;
    }
    
    private DNearCallback myNearCallback = new DNearCallback() {
        @Override
        public void call(Object data, DGeom o1, DGeom o2) {
            nearCallback(data, o1, o2);
        }
    };

    
    private class ContactPair {
        DContact contact;      
        DJointFeedback fb;
        ContactPair( DContact contact, DJointFeedback fb ) {
        	this.contact = contact;
        	this.fb = fb;
        }
    }

    List<ContactPair> L = new LinkedList<ContactPair>();

    /** 
     * this is called by dSpaceCollide when two objects in space are
     * potentially colliding.
     */
    private void nearCallback ( Object data, DGeom o1, DGeom o2 ) {
        // exit without doing anything if the two bodies are connected by a joint 
        DBody b1,b2;
        final int maxContacts = 1;
        DContactBuffer contacts = new DContactBuffer(maxContacts);
        
        b1 = o1.getBody();
        b2 = o2.getBody();
        if ( b1 != null && b2 != null && !enableContacts.getValue() ) return;
        if ( b1 != null && b2 != null && OdeHelper.areConnected(b1,b2)) return;        
        if ( b1 != null && nonCollidable.contains( b1 ) ) return; 
        if ( b2 != null && nonCollidable.contains( b2 ) ) return; 
        
        int collisions = OdeHelper.collide( o1,o2,maxContacts,contacts.getGeomBuffer() );
        if ( collisions > 0 ) { 
            for ( int i = 0; i < collisions; i++ ) {
                DContact contact = contacts.get(i);
                contact.surface.mode = 0;
                contact.surface.mu = friction.getValue();
                contact.surface.mu2 = 0;
                DContactJoint c = OdeHelper.createContactJoint ( world, contactgroup, contact);
                DJointFeedback fb = new DJointFeedback();
                c.setFeedback(fb);
                c.attach( b1, b2 );
                L.add( new ContactPair( contact, fb ) );
            }
        }
    }    
    
    @Override
    public String toString() {
    	final DecimalFormat df = new DecimalFormat("0.00");
    	return "time = " + df.format( elapsed );
    }
    
}