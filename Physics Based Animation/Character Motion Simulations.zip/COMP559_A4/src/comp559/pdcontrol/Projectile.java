package comp559.pdcontrol;

import java.awt.Color;
import java.util.Random;

import javax.vecmath.Point3d;
import javax.vecmath.Tuple3d;
import javax.vecmath.Vector3d;

import org.ode4j.math.DQuaternion;
import org.ode4j.ode.DBody;
import org.ode4j.ode.DBox;
import org.ode4j.ode.DMass;
import org.ode4j.ode.DSpace;
import org.ode4j.ode.DSphere;
import org.ode4j.ode.DWorld;
import org.ode4j.ode.OdeHelper;

import com.jogamp.opengl.GL;
import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;

import mintools.viewer.EasyViewer;
import mintools.viewer.FlatMatrix4d;

/**
 * Projectile to launch into the simulation as an obstacle
 * @author kry
 */
public class Projectile {

    private DBody body;
    private DMass bodyMass;
    
    boolean isSphere;
    
    private DSphere sphere;
    private double radius = 0.2;

    private DBox box;
    private Vector3d dim = new Vector3d( 0.3, 0.4, 0.6 );

    private float [] frontColour = { 0.7f, 0, 0, 1 };
    
    Point3d p0 = new Point3d( 0, 1.5, 1.5 );
    Vector3d v0 = new Vector3d( 0, 0, -5 );
    Vector3d omega0 = new Vector3d( 0, 0, 0 );
    
    /** 
     * Creates a random projectile 
     * randomly a sphere or box, of slightly varied size, of different colour, and initial conditions.
     */
    public Projectile( DWorld world, DSpace space ) {
        final Random r = new Random();

        isSphere = r.nextBoolean();
        
    	body = OdeHelper.createBody( world );
    	
	    bodyMass = OdeHelper.createMass();
	    if ( isSphere ) {
	    	radius += (r.nextFloat()-0.5)*0.1;
	    	bodyMass.setSphere( 1, radius );
	    	// density 1000 or 1 ???  not clear!  perhaps that's why people call adjustMass (i.e., to scale)
		    // bodyMass.adjust(1);
	    } else {
	    	perturbTuple(r, dim, 0.1);
	    	bodyMass.setBox( 1, dim.x, dim.y, dim.z );
	    	// bodyMass.adjust(1); // gross... but not working nicely...
	        // density 1000 or 1 ???  not clear!  perhaps that's why people call adjustMass (i.e., to scale)
	    }
	    body.setMass( bodyMass );

	    if ( isSphere ) {
	    	sphere = OdeHelper.createSphere( space, radius );
	    	sphere.setBody( body );
	    } else {
	    	box = OdeHelper.createBox( space, dim.x, dim.y, dim.z  );
	        box.setBody( body );   
	    }
	    
   	 	DQuaternion q = new DQuaternion(r.nextDouble()-0.5,r.nextDouble()-0.5,r.nextDouble()-0.5,r.nextDouble()-0.5);
   	 	q.normalize();
        perturbTuple(r, p0, 0.1);
        perturbTuple(r, v0, 2 );
        perturbTuple(r, omega0, 3 );
   	 	body.setPosition( p0.x, p0.y, p0.z );
        body.setQuaternion( q );
        body.setLinearVel( v0.x, v0.y, v0.z );
        body.setAngularVel( omega0.x, omega0.y, omega0.z );
	    
        Color c = Color.getHSBColor(r.nextFloat(), 0.7f, 1);
        frontColour[0] = c.getRed() / 255.0f;
        frontColour[1] = c.getGreen() / 255.0f;
        frontColour[2] = c.getBlue() / 255.0f;        
    }
    
    /**
     * Perturbs the given tuple by a random amount, drawn from the given random, 
     * values will increase or decrease by a maximum of s
     * @param r
     * @param t
     * @param s
     */
    private static void perturbTuple( Random r, Tuple3d t, double s ) {
    	t.x += (r.nextFloat()-0.5)*s*2;
    	t.y += (r.nextFloat()-0.5)*s*2;
    	t.z += (r.nextFloat()-0.5)*s*2;
    }
    
    /**
     * Destroies the body, which removes it from the space and the world.
     * The projectile should be removed from the projectile list and discarded after calling this method.
     */
    public void destroy() {
    	if ( isSphere ) {
		    sphere.destroy();
    	} else {
    		box.destroy();
    	}
    	// body.destroy();  must be called automatically by the geometry
    }
  
    public void display( GLAutoDrawable drawable ) {
    	GL2 gl = drawable.getGL().getGL2();    	
        float t = 1; // transparency in case we want the objects to fade away?
        final float[] specColour  = { .8f, .8f, .8f, t};
        final float[] zeroColour  = { 0, 0, 0, t};
        gl.glMaterialfv( GL.GL_FRONT, GL2.GL_AMBIENT, zeroColour, 0 );
        gl.glMaterialfv( GL.GL_FRONT, GL2.GL_DIFFUSE, frontColour, 0 );
        gl.glMaterialfv( GL.GL_FRONT, GL2.GL_SPECULAR, specColour, 0 );
        gl.glMateriali( GL.GL_FRONT, GL2.GL_SHININESS, 92 );
        
        gl.glPushMatrix();    
        final FlatMatrix4d M = new FlatMatrix4d();
        ODETools.setFlatMatrix( body, M );
        gl.glMultMatrixd( M.asArray(), 0 );
        if ( isSphere ) {
            EasyViewer.glut.glutSolidSphere(radius, 32,16); // radius set on creation!        	
        } else {
        	gl.glScaled( dim.x, dim.y, dim.z );
        	EasyViewer.glut.glutSolidCube(1);
        }
        gl.glPopMatrix();
    }
}
