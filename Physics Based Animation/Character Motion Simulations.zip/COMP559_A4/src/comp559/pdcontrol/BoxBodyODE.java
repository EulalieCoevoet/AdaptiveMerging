package comp559.pdcontrol;

import javax.vecmath.Matrix3d;
import javax.vecmath.Matrix4d;
import javax.vecmath.Point3d;
import javax.vecmath.Quat4d;
import javax.vecmath.Vector3d;

import org.ode4j.math.DQuaternion;
import org.ode4j.math.DVector3;
import org.ode4j.ode.DBody;
import org.ode4j.ode.DBox;
import org.ode4j.ode.DMass;
import org.ode4j.ode.DSpace;
import org.ode4j.ode.DWorld;
import org.ode4j.ode.OdeHelper;

import com.jogamp.opengl.GL;
import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.util.gl2.GLUT;

import mintools.parameters.BooleanParameter;
import mintools.viewer.EasyViewer;
import mintools.viewer.FlatMatrix4d;

/**
 * Implementation of some OpenGL glue and other utilities for creating body parts of a skeleton that can be simulated with ODE
 * @author kry
 */
public class BoxBodyODE {

    /** the name of this body */
    public String name;
    
    /** the ODE body object */
    public DBody body;
    /** the mass of the body */
    public DMass mass;
    /** the geometry of the body */
    public DBox box;
    
    private Vector3d dim = new Vector3d(1,1,1);
    private DVector3 p0 = new DVector3();
    private DQuaternion q0 = new DQuaternion(1,0,0,0);
    
    boolean selected = false;
    Point3d selectedPoint = new Point3d();
    
    /**
     * parameter to enable visual display of the name of boxbody objects
     */
    public static BooleanParameter displayName = new BooleanParameter( "display body names", false );
    
    /**
     * Creates a box shaped body for the skeleton body geometry.
     * @param name
     * @param world 
     * @param space
     * @param dimx
     * @param dimy
     * @param dimz
     * @param position
     * @param orientation
     */
    public BoxBodyODE( String name, DWorld world, DSpace space, double dimx, double dimy, double dimz, DVector3 position, DQuaternion orientation ) {
        this.name = name;
        this.dim.set( dimx, dimy, dimz );
        p0.set( position );
        q0.set( orientation );
        
        body = OdeHelper.createBody( world );
        mass = OdeHelper.createMass();
        mass.setBox( 1, dimx, dimy, dimz ); 
        // NOTE: density 1000 or 1 ???  not clear!  perhaps that's why people call adjustMass (i.e., to scale)
        body.setMass( mass );
        box = OdeHelper.createBox( space, dimx, dimy, dimz );
        box.setBody( body );        
    }
    
    private FlatMatrix4d M = new FlatMatrix4d();

    /**
     * Displays the body in its current position
     * @param drawable
     */
    public void display( GLAutoDrawable drawable ) {
        GL2 gl = drawable.getGL().getGL2();        
        float[] selectedColour = { 1f, 0, 0, 1};
        float[] frontColour = { 1f, 0, 0, 1};
        float[] specColour  = { 0, 0, 1f, 1};
        float[] zeroColour  = { 0, 0, 0, 1};
        if ( selected ) {
        	gl.glMaterialfv( GL.GL_FRONT, GL2.GL_AMBIENT, zeroColour, 0 );            
            gl.glMaterialfv( GL.GL_FRONT, GL2.GL_DIFFUSE, selectedColour, 0 );
        } else {
            gl.glMaterialfv( GL.GL_FRONT, GL2.GL_AMBIENT, zeroColour, 0 );            
            gl.glMaterialfv( GL.GL_FRONT, GL2.GL_DIFFUSE, frontColour, 0 );
        }
        gl.glMaterialfv( GL.GL_FRONT, GL2.GL_SPECULAR, specColour, 0 );
        gl.glColor3fv( frontColour, 0 );
        gl.glMateriali( GL.GL_FRONT, GL2.GL_SHININESS, 92 );
        
        gl.glPushMatrix();        
        
        ODETools.setFlatMatrix( body, M );
        gl.glMultMatrixd( M.asArray(), 0 );
        
        if ( selected ) {
        	gl.glPushMatrix();
    		gl.glTranslated( selectedPoint.x, selectedPoint.y, selectedPoint.z );
    		EasyViewer.glut.glutSolidSphere(0.025,16,16);
        	gl.glPopMatrix();
        }
        
        gl.glScaled( dim.x, dim.y, dim.z );
        EasyViewer.glut.glutSolidCube(1);
        //EasyViewer.glut.glutSolidSphere(.5,16,10); // alternate way of viewing the model, not consistent with collision detection.
        
        if ( displayName.getValue() ) {
            gl.glDisable( GL2.GL_LIGHTING );
            gl.glColor4f(1,1,1,0.8f);
            gl.glBegin( GL.GL_LINES );
            gl.glVertex3d(0,0,0);
            gl.glVertex3d(0,0,0.5);
            gl.glEnd();
            gl.glRasterPos3d(0,0,.5);
            EasyViewer.glut.glutBitmapString(GLUT.BITMAP_8_BY_13, name);
            gl.glEnable( GL2.GL_LIGHTING );
        }
        gl.glPopMatrix();
    }

	/**
     * Sets the configuration of this body to the given homogeneous transformation matrix
     * @param EwfromRB
     */
    public void setPosition( Matrix4d EwfromRB ) {
        Matrix3d R = new  Matrix3d();
        Vector3d p = new Vector3d();
        EwfromRB.getRotationScale(R);
        EwfromRB.get(p);
        Quat4d q = new Quat4d();
        q.set(R);
        if ( q.w < 0 ) {
            System.out.println(" watch out!" );
        }
        DVector3 ptmp = new DVector3( p.x, p.y, p.z );
        DQuaternion qtmp = new DQuaternion(  q.w, q.x, q.y, q.z ); // note real comes first in a DQuaternion?? 
        body.setPosition( ptmp );
        body.setQuaternion( qtmp );
        body.setLinearVel( 0,0,0 );
        body.setAngularVel( 0,0,0 );
    }
    
    /**
     * Sets the velocity of this body, given the body's velocity in world coordinates
     * CAREFUL: specifically, should take the body velocity in world aligned body coordinates.
     * This is perhaps poorly documented in ODE!
     * @param vel
     * @param omega
     */
    public void setVelocity( DVector3 vel, DVector3 omega ) {        
        DVector3 pos = new DVector3( body.getPosition() );
        DVector3 tmp = new DVector3();
        DVector3 v = new DVector3( vel);
        DVector3 w = new DVector3( omega );
        tmp.eqCross( w, pos );
        v.add( tmp );
        body.setLinearVel( v );
        body.setAngularVel( w );
    }
    
    /**
     * Resets the position of this body to its initial configuration
     */
    public void reset() {
        body.setPosition( p0 );
        body.setQuaternion( q0 );
        body.setLinearVel( 0,0,0 );
        body.setAngularVel( 0,0,0 );
    }
}
