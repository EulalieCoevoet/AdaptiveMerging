package comp559.pdcontrol;

import javax.vecmath.Matrix3d;
import javax.vecmath.Matrix4d;
import javax.vecmath.Quat4d;
import javax.vecmath.Tuple3d;

import org.ode4j.math.DMatrix3C;
import org.ode4j.math.DQuaternionC;
import org.ode4j.math.DVector3C;
import org.ode4j.ode.DBody;

import mintools.viewer.FlatMatrix4d;

/**
 * Some helper functions to bridge the gap between vecmath, mintools, and ODE
 * @author kry
 */
public class ODETools {

    public static void setVecmathFromODE( Tuple3d v, DVector3C d ) {
    	v.x = d.get0();
    	v.y = d.get1();
    	v.z = d.get2();
    }
    
    /**
     * Sets the provided homogeneous 4x4 matrix A using the current position and orientation of the body ODE rigid body b 
     * @param b
     * @param A
     */
    public static void setFlatMatrix( DBody b, FlatMatrix4d A ) {
        DVector3C p = b.getPosition();
        DMatrix3C R = b.getRotation();
        Matrix4d m = A.getBackingMatrix();
        m.setIdentity();
        for (int i = 0; i < 3; i++ ) {
            for ( int j = 0; j < 3; j ++ ) {
                m.setElement(i, j, R.get(i, j) );
            }
            m.setElement(i, 3, p.get(i) );
        }
    }
    
    public static void getRotation(DBody b, Matrix3d R) {
    	DMatrix3C M = b.getRotation();
    	for (int i = 0; i < 3; i++ ) {
            for ( int j = 0; j < 3; j ++ ) {
                R.setElement(i, j, M.get(i, j) );
            }
    	}
    }
    
    /**
     * Sets a vecmath quaternion from an open dynamics engine quaternion
     * @param dst
     * @param src
     */
    public static void setQuat4d( Quat4d dst, DQuaternionC src ) {
        dst.w = src.get0();
        dst.x = src.get1();
        dst.y = src.get2();
        dst.z = src.get3();
    }
    
}
