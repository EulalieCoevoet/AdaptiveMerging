package comp559.pdcontrol;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.vecmath.Matrix3d;
import javax.vecmath.Matrix4d;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

import org.ode4j.math.DVector3;

import com.jogamp.opengl.GL;
import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.util.gl2.GLUT;

import mintools.parameters.BooleanParameter;
import mintools.parameters.DoubleParameter;
import mintools.swing.CollapsiblePanel;
import mintools.swing.VerticalFlowPanel;
import mintools.viewer.EasyViewer;
import mintools.viewer.FancyAxis;
import mintools.viewer.FlatMatrix4d;
import mintools.viewer.SceneGraphNode;

/**
 * A node in a hierarchy or an articulated character.  Each node represents 
 * a joint which rotates about a point which is offset from the parent node's frame. 
 * @author kry
 */
public class SkeletonNode implements SceneGraphNode {

    /**
     * The name of this node 
     */
    public String name;
    
    /**
     * The index of this node to identify it in an external array of all nodes 
     */
    public int index;
    
    /**
     * The parent of this node, or null if it is the root 
     */
    public SkeletonNode parent = null;
    
    /** 
     * List of children nodes 
     */
    public List<SkeletonNode> children = new ArrayList<SkeletonNode>();
    
    /**
     * Offset of this node with respect to parent
     */
    public Point3d offset = new Point3d();
    
    /**
     * List of channels from the BVH file.  This is used to define the order
     * in which this skeleton node applies its transformations.
     */
    public ArrayList<String> chanlist;
    
    /** x translation */
    public DoubleParameter xTrans = new DoubleParameter( "x", 0, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY );
    /** y translation */
    public DoubleParameter yTrans = new DoubleParameter( "y", 0, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY );
    /** z translation */
    public DoubleParameter zTrans = new DoubleParameter( "z", 0, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY );
    /** x Rotation */
    public DoubleParameter xRot = new DoubleParameter( "xRot", 0, -3.14, 3.14 );
    /** y Rotation */
    public DoubleParameter yRot = new DoubleParameter( "yRot", 0, -3.14, 3.14 );
    /** z Rotation */
    public DoubleParameter zRot = new DoubleParameter( "zRot", 0, -3.14, 3.14 );
    /** reference to the ode body that represents this skeleton node */
    public BoxBodyODE odeBody;
    
    /**
     * Creates a new skeleton node with no parent and the given name.
     * The offset defaults to zero, and the default rotation order without
     * a channel list from a BVH file is z y x.
     * @param name
     */
    public SkeletonNode( String name ) {        
        this.name = name;
    }
        
    /**
     * Adds a child node to this node and sets this node as 
     * the child's parent.
     * @param n
     */
    public void addChild( SkeletonNode n ) {
        n.parent = this;
        children.add( n );
    }
        
    /** 
     * Position of the bounding volume geometry that represents this skeleton node 
     */
    public Point3d geometryPosition = new Point3d();
    
    /**
     * Size in each axis direction of the bounding volume geometry that represents this skeleton node
     * (some heruistics are used to choose a reasonable size, which is not necessarily realistic) 
     */
    public Vector3d geometrySize = new Vector3d();

    /**
     * Finds bounding geometry for this node based on its
     * location and the location of its children, then 
     * calls init on children.
     */
    @Override
    public void init(GLAutoDrawable drawable) {
        // lower left and upper right positions
        Point3d gll = new Point3d();
        Point3d gur = new Point3d();
   
        for ( SkeletonNode s : children ) {
            if ( s.offset.x < gll.x ) gll.x = s.offset.x;
            if ( s.offset.y < gll.y ) gll.y = s.offset.y;
            if ( s.offset.z < gll.z ) gll.z = s.offset.z;
            if ( s.offset.x > gur.x ) gur.x = s.offset.x;
            if ( s.offset.y > gur.y ) gur.y = s.offset.y;
            if ( s.offset.z > gur.z ) gur.z = s.offset.z;
        }
        geometryPosition.add( gll, gur );
        geometryPosition.scale( 0.5 );            
        geometrySize.sub( gur, gll );
        geometrySize.scale( 0.5 );
        
        // make sure that nothing is completely flat!
        double size = axisSize.getValue();
        geometrySize.x = ( geometrySize.x < size ) ? size : geometrySize.x; 
        geometrySize.y = ( geometrySize.y < size ) ? size : geometrySize.y;
        geometrySize.z = ( geometrySize.z < size ) ? size : geometrySize.z;

        for ( SkeletonNode c : children ) {
            c.init( drawable );
        }
    }
    
    /**
     * Geometry for an axis for showing the orientation of each joint
     */
    private static FancyAxis fa = new FancyAxis();
    
    /**
     * Parameter for scaling the axes shown at the joints and the geometry around each bone.
     * This is made public so that the size can be easily set when loading different data that
     * was recorded with different units (e.g., Vicon data from the CMU database, or our own 
     * natural point motion capture).
     */
    public static DoubleParameter axisSize = new DoubleParameter( "axis size (meters)", 0.05, 0.001, 1 );
    
    private static BooleanParameter drawLines = new BooleanParameter( "draw skeleton lines", false );
    private static BooleanParameter drawAxes= new BooleanParameter( "draw joint axes", false );
    private static BooleanParameter drawGeometry = new BooleanParameter( "draw skeleton geometry", true );
    private static BooleanParameter drawNames = new BooleanParameter( "draw skeleton names", false );
    private static DoubleParameter drawGeometrytransparency = new DoubleParameter( " skeleton geometry transparency", 0.10, 0, 1 );
    
    /**
     * Gets the control panel for adjusting the display of all skeleton nodes
     * @return a control panel
     */
    public static JPanel getStaticControls() {
        VerticalFlowPanel vfp = new VerticalFlowPanel();
        vfp.setBorder( new TitledBorder("Skeleton drawing controls" ) );
        vfp.add( drawAxes.getControls() );
        vfp.add( drawLines.getControls() );
        vfp.add( drawGeometry.getControls() );
        vfp.add( drawNames.getControls() );
        vfp.add( BoxBodyODE.displayName.getControls() );
        vfp.add( axisSize.getSliderControls(true) );
        vfp.add( drawGeometrytransparency.getSliderControls(false) );
        CollapsiblePanel cp = new CollapsiblePanel( vfp.getPanel());
        cp.collapse();
        return cp;
    }
    
    /**
     * Displays the skeleton BVH either with lines or ghost scaled wire cubes as selected
     */
    @Override
    public void display(GLAutoDrawable drawable) {
        GL2 gl = drawable.getGL().getGL2();
        
        // can draw a line segment as part of the skeleton
        if ( drawLines.getValue() ) {
            gl.glDisable( GL2.GL_LIGHTING );
            gl.glColor4d( 1, 1, 1, 0.5 );
            gl.glLineWidth(3);
            gl.glBegin(GL.GL_LINES);
            gl.glVertex3d(0,0,0);
            gl.glVertex3d(offset.x, offset.y, offset.z);
            gl.glEnd();
            gl.glEnable( GL2.GL_LIGHTING );
        }
        
        // get the transform that brings us to the location of 
        // this joint with respect to its parent, and apply
        gl.glPushMatrix();
        getTransform( T.getBackingMatrix() );
        gl.glMultMatrixd( T.asArray(), 0 );
                
        // Draw a transparent scaled wire cube for the geometry, if requested        
        if ( drawGeometry.getValue() && children.size() != 0 ) {
            gl.glPushMatrix();
            gl.glTranslated( geometryPosition.x, geometryPosition.y, geometryPosition.z );
            // use the size of the bounding box to draw the geometry, but 
            // make sure that each dimension is at least a minimum specified size.
            tmpVector.set( geometrySize );
            double size = axisSize.getValue();
            tmpVector.x = ( geometrySize.x < size ) ? size : geometrySize.x; 
            tmpVector.y = ( geometrySize.y < size ) ? size : geometrySize.y;
            tmpVector.z = ( geometrySize.z < size ) ? size : geometrySize.z;
            gl.glScaled( tmpVector.x, tmpVector.y, tmpVector.z );            
            gl.glLineWidth(1);
            gl.glDisable(GL2.GL_LIGHTING);
            gl.glColor4f(1,1,1, drawGeometrytransparency.getFloatValue() );
            EasyViewer.glut.glutWireCube( 2 );
            gl.glEnable(GL2.GL_LIGHTING);
            gl.glPopMatrix();
        }
        
        if ( drawAxes.getValue() ) {
            fa.setSize( axisSize.getValue() * 4 );
            fa.draw(gl);
        }
        if ( drawNames.getValue() ) {
            gl.glDisable( GL2.GL_LIGHTING );
            gl.glColor4f(1,1,1,1);
            gl.glRasterPos3d( 0,0,0 );            
            EasyViewer.glut.glutBitmapString(GLUT.BITMAP_8_BY_13, name);
            gl.glEnable( GL2.GL_LIGHTING );
        }
        
        for ( SkeletonNode c : children ) {
            c.display(drawable);
        }
        
        gl.glPopMatrix();
    }
    
    private FlatMatrix4d T = new FlatMatrix4d();
    private Matrix4d tmpMatrix = new Matrix4d();
    private Matrix4d tmpMatrix2 = new Matrix4d();
    private Vector3d tmpVector = new Vector3d();

    /**
     * Gets the transformation between this node and its parent.
     * 
     * Note, this method deals with translation in a way that might be cheating
     * slightly. There is nothing to say that the translation channels can be
     * mixed with the rotation channels (i.e., they don't appear all at the
     * beginning of the channel list). But in all examples I've seen, these
     * translations come first, so this will very likely work for just about any
     * bvh file.
     * 
     * @param m
     */
    public void getTransform( Matrix4d m ) {
        tmpVector.set( xTrans.getValue(), yTrans.getValue(), zTrans.getValue() );
        tmpVector.add( offset );
        // set the translation part of the matrix
        m.set( tmpVector );
        // now compute and set the rotation part of the matrix.
        if ( chanlist != null ) {
            for( String chan : chanlist ) {
                if ( chan.equals("Xrotation") ) {
                    tmpMatrix.rotX(xRot.getValue());
                    m.mul(tmpMatrix);
                } else if ( chan.equals("Yrotation") ) {
                    tmpMatrix.rotY(yRot.getValue());
                    m.mul(tmpMatrix);
                } else if ( chan.equals("Zrotation") ) {
                    tmpMatrix.rotZ(zRot.getValue());
                    m.mul(tmpMatrix);
                }
            }
        } else {
            // just use a default order if there is no channel list
            tmpMatrix.rotX(zRot.getValue());
            m.mul(tmpMatrix);
            tmpMatrix.rotY(xRot.getValue());
            m.mul(tmpMatrix);
            tmpMatrix.rotZ(yRot.getValue());
            m.mul(tmpMatrix);
        }
    }
    
    /**
     * Frames from the previous frame which can be used to compute world velocity of this body.
     */
    public Matrix4d EwfrombPrevious = new Matrix4d();
    
    /** linear part of the twist produced by this joint's velocity, in world coordinates */
    public Vector3d worldVelocity = new Vector3d();
    
    /** angular part of the twist produced by this joint's velocity, in world coordinates */
    public Vector3d worldOmega = new Vector3d();
    
    /**
     * Creates a snapshot of the current pose, to be compared with another pose to compute the velocity of bodies
     */
    public void copyEwfrombToPrevious() {
        EwfrombPrevious.set( Ewfromb.getBackingMatrix() );
        for( SkeletonNode n : children ) {
            n.copyEwfrombToPrevious();
        }
    }
    
    /**
     * World linear velocity of the body.
     */
    public DVector3 v = new DVector3();
    /** 
     * World angular velocity of the body.  See comment above on computation. 
     */
    public DVector3 w = new DVector3();
    
    /**
     * Computes the world coordinate twist caused by this joint using 
     * the previous and current transform and the given time step.
     * Note that the program flow to compute this is a bit involved.
     * The process is driven by the pose setting code in 
     * PDControlApp.Display and has the following steps:  
     * 1) set the skeleton from the bvh
     * 2) compute transforms
     * 3) save a copy with copyEwfrombToPrevious
     * 4) set the skeleton from the bvh for the next frame in the animation
     * 5) compute transforms
     * 6) call computeWorldTwist on each node in the skeleton with the stepsize between frames.  
     * @param h 
     */
    public void computeWorldTwist( double h ) {

    	// TODO: (Objective 2) Write code to compute the linear velocity of the ODE body
    	// TODO: (Objective 3) Write code to compute the angular velocity of the ODE body

    
    	Matrix4d incremental_E = new Matrix4d();
    	Matrix4d invert_Matrix = new Matrix4d(EwfrombPrevious);
    	invert_Matrix.invert();
    	
    	
    	incremental_E.mul(Ewfromb.getBackingMatrix(),invert_Matrix);
    	
    	
    	Vector3d linear_velocity = new Vector3d();
    	incremental_E.get(linear_velocity);
    	linear_velocity.scale(1/h);
    
    	//v.set(linear_velocity.x, linear_velocity.y, linear_velocity.z); 
    	
    	// Rinc = R*R-1prev
    	
    	Matrix3d rotational = new Matrix3d();
    	incremental_E.get(rotational);
    	
    	Matrix3d I = new Matrix3d();
    	I.setIdentity();
    	I.mul(-1);
    	
    	rotational.add(I);
    //	rotational.mul();
    	
    	Vector3d omega = new Vector3d(-rotational.m12, 
    								rotational.m02, 
    								-rotational.m01); 
  	    omega.scale(1/h);
    	
    	
    	w.set(omega.x, omega.y, omega.z);
    	
    	Vector3d r = new Vector3d(this.geometryPosition);
    	r.cross(r, omega);
    	
    	linear_velocity.add(r);
    	
    	
    	//take into account rotating around the joint
    	v.set(linear_velocity.x, linear_velocity.y, linear_velocity.z);
    	// Overall, you want to compute compute the world coordinate twist for this body!
        // use EwfromPrevious and the current Ewfromb to find the world transform 
        // from the previous time step to the current time step.  From that you can
        // estimate linear and angular components of the rotation.
        // Note that you will probably find it easiest to use a first order approximation
        // of the exponential map:  R(w,theta) = I + [w]theta + O(theta^2)
        // Be sure to divide by the time step h so that you have a velocity!        
        // TODO: (Objective 2) Store your result in v 
    	// TODO: (Objective 3) Store your result in w
    	
    	

    	
    	
    	
    	
    }
    
    /**
     * Transformation from the body frame to the world frame
     */
    public FlatMatrix4d EwfrompT = new FlatMatrix4d(); 
    /**
     * Cumulative transforms for each of the rotations
     */
    public FlatMatrix4d EwfrompTR[] = null;
    /**
     * Total transformation including both translation and rotation
     */
    public FlatMatrix4d Ewfromb = null;
    
    private Matrix4d R[] = { new Matrix4d(), new Matrix4d(), new Matrix4d() };
    
    /**
     * The axis associated with each of the rotations
     */
    public Vector3d axis[] = { new Vector3d(), new Vector3d(), new Vector3d() };
    
    /**
     * Computes all the transforms of all the body parts
     */
    public void computeTransforms( ) {
        Matrix4d I = new Matrix4d();
        I.setIdentity();
        computeTransformHelper( I );
    }
    
    private void computeTransformHelper( Matrix4d m ) {
        
        if ( EwfrompTR == null ) {
            EwfrompTR = new FlatMatrix4d[3];        
            for ( int i = 0; i < 3; i++ ) {
                EwfrompTR[i] = new FlatMatrix4d();
            }      
            Ewfromb = EwfrompTR[2];
        }
        
        tmpVector.set( xTrans.getValue(), yTrans.getValue(), zTrans.getValue() );
        tmpVector.add( offset );
        tmpMatrix2.set( tmpVector ); // set the matrix to a translation matrix
                
        EwfrompT.getBackingMatrix().mul( m, tmpMatrix2 );
        
        if ( chanlist != null ) {
            int i = 0;
            for( String chan : chanlist ) {
                if ( chan.equals("Xrotation") ) {
                    axis[i].set(1,0,0);
                    R[i++].rotX(xRot.getValue());                        
                } else if ( chan.equals("Yrotation") ) {
                    axis[i].set(0,1,0);
                    R[i++].rotY(yRot.getValue());                    
                } else if ( chan.equals("Zrotation") ) {
                    axis[i].set(0,0,1);
                    R[i++].rotZ(zRot.getValue());
                }
            }
        } else {
            // just use a default order if there is no channel list
            axis[0].set(1,0,0);
            R[0].rotX(zRot.getValue());
            axis[1].set(0,1,0);
            R[1].rotY(xRot.getValue());
            axis[2].set(0,0,1);
            R[2].rotZ(yRot.getValue());            
        }
        
        EwfrompTR[0].getBackingMatrix().mul(EwfrompT.getBackingMatrix(), R[0] );
        EwfrompTR[1].getBackingMatrix().mul(EwfrompTR[0].getBackingMatrix(), R[1] );
        EwfrompTR[2].getBackingMatrix().mul(EwfrompTR[1].getBackingMatrix(), R[2] );
        
        for ( SkeletonNode c : children ) {
            c.computeTransformHelper(EwfrompTR[2].getBackingMatrix());
        }
    }
    
    /**
     * Resets the skeleton hierarchy to its zero pose.
     * Note that this is often the same as the T pose.
     */
    public void resetToZeroPose() {
        xTrans.setValue( 0.0 );
        yTrans.setValue( 0.0 );
        zTrans.setValue( 0.0 );
        zRot.setValue( 0.0 );
        xRot.setValue( 0.0 );
        yRot.setValue( 0.0 );
        for ( SkeletonNode n : children ) {
            n.resetToZeroPose();
        }
    }
        
    @Override   
    public JPanel getControls() {
        VerticalFlowPanel vfp = new VerticalFlowPanel();
        vfp.setBorder( new TitledBorder( name ) );
        VerticalFlowPanel vfp2 = new VerticalFlowPanel();
        vfp2.setBorder( new TitledBorder ("parameters"));
        vfp2.add( xTrans.getControls() );
        vfp2.add( yTrans.getControls() );
        vfp2.add( zTrans.getControls() );        
        vfp2.add( xRot.getSliderControls(false) );
        vfp2.add( yRot.getSliderControls(false) );
        vfp2.add( zRot.getSliderControls(false) );
        CollapsiblePanel cp = new CollapsiblePanel( vfp2.getPanel() );
        cp.collapse();
        vfp.add( cp );
        for ( SkeletonNode c : children ) {
            vfp.add( c.getControls() );
        }        
        return vfp.getPanel();
    }    
    
    @Override
    public String toString() {     
        return toStringWithPrefix("");
    }

    /**
     * Builds a nicely indented string description of the skeleton's structure
     * @param prefix
     * @return a string describing the skeleton
     */
    private String toStringWithPrefix( String prefix ) {
        String s = prefix + name + "\n";
        for ( SkeletonNode c : children ) {
            s += c.toStringWithPrefix( prefix + "  " );
        }
        return s;
    }
}
