package comp559.pdcontrol;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.vecmath.AxisAngle4d;
import javax.vecmath.Matrix3d;
import javax.vecmath.Matrix4d;
import javax.vecmath.Point3d;
import javax.vecmath.Quat4d;
import javax.vecmath.Vector3d;

import org.ode4j.math.DQuaternion;
import org.ode4j.math.DVector3;
import org.ode4j.ode.DBallJoint;
import org.ode4j.ode.DBody;
import org.ode4j.ode.DJointGroup;
import org.ode4j.ode.DSpace;
import org.ode4j.ode.DWorld;
import org.ode4j.ode.OdeHelper;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;

import mintools.parameters.BooleanParameter;
import mintools.parameters.DoubleParameter;
import mintools.swing.CollapsiblePanel;
import mintools.swing.VerticalFlowPanel;

/**
 * Class to handle the ODE bodies that make up a skeleton, and provide control
 * to intialize from motion capture and to follow motion capture using joint torques.
 * @author kry
 */
public class Skeleton {

    private DWorld world;
    private DSpace space;    
    private DJointGroup skeletonJointGroup; 

    ArrayList<BoxBodyODE> bodies = new ArrayList<BoxBodyODE>();
    ArrayList<MarionetteSpring> springs = new ArrayList<MarionetteSpring>();

    /** Set of bodies that ODE should ignore for collision */
    public Set<DBody> nonCollidable = new HashSet<DBody>();

    private SkeletonNode root;

    /**
     * Creates a skeleton.  
     * Note that each node in the SkeletonNode heirarchy will be assigned a corresponding
     * ODE rigid body object, so if you create multiple ODESkeletons, then each should have its
     * own SkeletonNode hierarchy.
     * @param world
     * @param space
     * @param rootNode
     */
    public Skeleton( DWorld world, DSpace space, SkeletonNode rootNode ) {
        this.world = world;
        this.space = space;
        this.root = rootNode;
        skeletonJointGroup = OdeHelper.createJointGroup();
        createSkeleton( root );
    }
    
    /**
     * Careful with this parameter... should be joint specific.  Currently as high as 1 and low as 0.1 are 
     * reasonable.  Should be inertia weighted.  Should double check inertia settings of bodies due to 
     * unclear documentation with respect to density parameter.
     */
    private static DoubleParameter stiffnessParam = new DoubleParameter( "ball joint stiffness", 0.2, 1e-3, 1e3 );
    private static DoubleParameter dampingParam = new DoubleParameter( "ball joint damping", 0.005, 1e-3, 1e3 );   // current stiffness and damping comes from questionable masses??    
    private static BooleanParameter applyStiffness = new BooleanParameter( "apply stiffness torques", true );
    private static BooleanParameter applyDamping = new BooleanParameter( "apply damping torques", true ); 

//    private static BooleanParameter hipsOnly = new BooleanParameter("follow hips only", false);
    
    /**
     * @return a control panel for adjusting simulation and viewing parameters
     */
    static public JPanel getControls() {
        VerticalFlowPanel vfp = new VerticalFlowPanel();
        vfp.setBorder(new TitledBorder("PD Control Parameters"));
        
        vfp.add( applyStiffness.getControls() );
        vfp.add( stiffnessParam.getSliderControls(true) );
        vfp.add( applyDamping.getControls() );
        vfp.add( dampingParam.getSliderControls(true) );        
//        vfp.add( hipsOnly.getControls() );

        CollapsiblePanel cp = new CollapsiblePanel( vfp.getPanel() );
        return cp;
    }
    
    /**
     * Creates a skeleton from the given hierarchy root node.
     * @param rootNode
     */
    private void createSkeleton( SkeletonNode rootNode ) {
        this.root = rootNode;
        root.resetToZeroPose();        
        root.computeTransforms();
        createSkeletonHelper(root );
    }
    
    private void createSkeletonHelper( SkeletonNode node ) {
        if ( node.name.compareTo("End Site") == 0 )  {
        	if ( ! node.parent.name.contains("Ankle") ) {
	        	MarionetteSpring s = new MarionetteSpring( node.parent );
	        	springs.add(s);
        	}
        	return;
        }
        
        // TODO: (Objective 1) Observe how the body is created in the node frame at geometryPosition
        Matrix4d E = node.Ewfromb.getBackingMatrix();
        Matrix3d R = new  Matrix3d();
        Vector3d p0 = new Vector3d();
        E.getRotationScale(R);
        E.get(p0);
        Quat4d q0 = new Quat4d();
        q0.set(R);        
        p0.add( node.geometryPosition );
        
        DVector3 dp0 = new DVector3( p0.x, p0.y, p0.z );
        DQuaternion dq0 = new DQuaternion( q0.w, q0.x, q0.y, q0.z );
        
        double dimx = node.geometrySize.x * 2;
        double dimy = node.geometrySize.y * 2;
        double dimz = node.geometrySize.z * 2;        
        BoxBodyODE b = new BoxBodyODE( node.name, world, space, dimx, dimy, dimz, dp0, dq0 );
        node.odeBody = b;
        bodies.add(b);
        for ( SkeletonNode child : node.children ) {
            createSkeletonHelper(child);
        }
        
        // the Collar and the Chest cause serious problems for collision 
        // with ODE because they can often interpenetrate with non-adjacent bodies
        // in many natural poses.  Note that adjacent bodies are automatically ignored
        // in collision detection 
        if ( node.name.contains("Collar") ) nonCollidable.add(b.body);
        if ( node.name.contains("Chest") ) nonCollidable.add(b.body);
    }
    
    /**
     * Creates the skeleton joints.  MUST be done after a reset!
     * (i.e., careful with order of object initialization) 
     * @param node
     */
    public void createSkeletonJoints( SkeletonNode node ) {
        if ( node.name.compareTo("End Site") == 0 ) return;
        if ( node.parent != null ) { // && !node.name.contains("Chest") ) {
        	Point3d anchorPos = new Point3d();
            // TODO: (Objective 4) Write code to compute and set joint anchor position (world coordinates)
        	Point3d anchorPosParent = new Point3d();
        	//if (node.parent != null) {
	       // 	anchorPosParent.add(node.offset);
	      //  	node.parent.Ewfromb.getBackingMatrix().transform((anchorPosParent));
        	//}
        	node.Ewfromb.getBackingMatrix().transform(anchorPos);
        	
        	anchorPos.add(anchorPosParent);
        	//anchorPos.scale(1/2);
        	

        //	node.EwfrombPrevious.transform(anchorPos);
        	
        	
            
            // note that NOT everything is a ball joint, but it is convenient here
            DBallJoint  ball = OdeHelper.createBallJoint(world, skeletonJointGroup);
            ball.attach( node.odeBody.body, node.parent.odeBody.body );            
            ball.setAnchor( anchorPos.x, anchorPos.y, anchorPos.z );                   
        }
        for ( SkeletonNode child : node.children ) {
            createSkeletonJoints( child );
        }
    }
        
    /**
     * Sets the state of the skeleton rigid bodies to the current position of its associated SkeletonNode.
     */
    public void setCurrentPose() {
        setCurrentPoseHelper( root );
    }
    
    private void setCurrentPoseHelper( SkeletonNode node ) {
        if ( node.name.compareTo("End Site") == 0 ) return;
      
        // TODO: (Objective 1) Write code to set the current pose 
        // use the transformation from the skeleton node to the world
        // along with the position of the center of mass of the body
        // (given by geometryPosition), to build a transformation for
        // the odeBody).  Note that odeBody.setPosition takes a 
        // scale parameter because the bvh is in different units
        // than the simulation (mm vs meters).  Use the scale member
        // variable that was set at construction!
    //    Vector3d p = new Vector3d(node.geometryPosition);
      //  Matrix4d translation= new Matrix4d();
    
        //node.Ewfromb.getBackingMatrix());
        
        Vector3d p = new Vector3d(node.geometryPosition);
        Matrix4d translation = new Matrix4d(1, 0, 0, p.x,
        									0, 1, 0, p.y,
        									0, 0, 1, p.z, 
        									0, 0, 0, 1	);
        
        Matrix4d nodeTransform = new Matrix4d();
        nodeTransform.set(node.Ewfromb.getBackingMatrix());
        nodeTransform.mul(nodeTransform, translation);
        
      
        


       
  

        node.odeBody.setPosition(nodeTransform);
        
        
        
        
        
        for ( SkeletonNode child : node.children ) {
            setCurrentPoseHelper(child);
        }
    }
    
    /**
     * Sets the current pose velocity for the given node and its children
     * NOTE proper velocity computation must come from comparing frames.
     * Doing this from successive joint angles will be painful and problematic!!
     * (CLASSIC problem with Euler angles)
     * @param h
     */
    public void setCurrentPoseVelocity( double h ) {
        setCurrentPoseVelocityHelper(root, h);
    }
    
    private void setCurrentPoseVelocityHelper( SkeletonNode node, double h ) {
        if ( node.name.compareTo("End Site") == 0 ) return;        
        node.computeWorldTwist( h );
//        if ( ! hipsOnly.getValue() || node.name.compareTo("Hips") == 0 ) {
            node.odeBody.setVelocity( node.v, node.w );
//        }
        for ( SkeletonNode child : node.children ) {
            setCurrentPoseVelocityHelper( child, h );
        }        
    }
    
    /**
     * Applies torque to the joints to pull the character towards the current
     * pose of its associated skeleton. 
     */
    public void applyJointTorques() {
        applyJointTorquesHelper(root);
    }
    
    private void applyJointTorquesHelper( SkeletonNode node ) {
        if ( node.name.compareTo("End Site") == 0 ) return;
        if ( node.parent != null ) {
            if ( applyStiffness.getValue() ) { // && node.name.contains("Hip") ) {            	
            	
                // TODO: (Objective 6) Write code to implement joint springs
            	
            	////do the ODE stuff to eventually get an ODE_Rbfromp matrix
            	Matrix3d ODE_Rwfromb= new Matrix3d();
            	Matrix3d ODE_Rwfromp = new Matrix3d();
            	Matrix3d ODE_Rpfromw= new Matrix3d();
            	Matrix3d ODE_Rpfromb = new Matrix3d();
            	Matrix3d ODE_Rbfromp = new Matrix3d();
            
            	ODETools.getRotation(node.odeBody.body, ODE_Rwfromb);
            	ODETools.getRotation(node.parent.odeBody.body, ODE_Rwfromp);
            	
            	ODE_Rpfromw.set(ODE_Rwfromp);
            	ODE_Rpfromw.invert();
            	
            	ODE_Rpfromb.mul(ODE_Rpfromw, ODE_Rwfromb);
           
            	ODE_Rbfromp.set(ODE_Rpfromb);
            	ODE_Rbfromp.invert();
            	
            	
            	//do the same thing for BVH, to eventually get a BVH_Rpfromb matrix
            	Matrix3d BVH_Rwfromb = new Matrix3d();
            	Matrix3d BVH_Rwfromp = new Matrix3d();
            	Matrix3d BVH_Rpfromw= new Matrix3d();
            	Matrix3d BVH_Rpfromb = new Matrix3d();
        
            	node.Ewfromb.getBackingMatrix().getRotationScale(BVH_Rwfromb);
            	node.parent.Ewfromb.getBackingMatrix().getRotationScale(BVH_Rwfromp);

            	BVH_Rpfromw.set(BVH_Rwfromp);
            	BVH_Rpfromw.invert();
      
            	BVH_Rpfromb.mul(BVH_Rpfromw, BVH_Rwfromb);
            	
            	
            	
            	//extract omega and theta
            	Matrix3d expwTheta = new Matrix3d();
            	expwTheta.mul(ODE_Rbfromp, BVH_Rpfromb);
            	
            	AxisAngle4d axisAngle = new AxisAngle4d();
            	axisAngle.set(expwTheta);
            	
            	double [] xyzt = new double[4];
           
            	axisAngle.get(xyzt);
            	
            	Vector3d w = new Vector3d(xyzt[0], xyzt[1], xyzt[2]);
            	
            	double theta = xyzt[3];
            
            	w.scale(theta*this.stiffnessParam.getValue());
            	ODE_Rwfromb.transform(w);

            	node.odeBody.body.addTorque(w.x, w.y, w.z);
            	node.parent.odeBody.body.addTorque(-w.x, -w.y, -w.z);
            	
            	
            	
            	
            	
            }
            if ( applyDamping.getValue() ) {
            	
                // TODO: (Objective 7) Write code to implement joint damping S
            	
            	DVector3 vc = new DVector3(node.odeBody.body.getAngularVel());
            	Vector3d vel_child= new Vector3d(vc.get0(), vc.get1(), vc.get2());
            	
            	DVector3 vp = new DVector3(node.parent.odeBody.body.getAngularVel());
            	Vector3d vel_parent= new Vector3d(vp.get0(), vp.get1(), vp.get2());
            
            	Vector3d velocity = new Vector3d();
            	velocity.sub(vel_parent, vel_child);
            	
            	velocity.scale(this.dampingParam.getValue());
    
            	node.odeBody.body.addTorque( velocity.x, velocity.y, velocity.z);
            	
         
            	node.parent.odeBody.body.addTorque( -velocity.x, -velocity.y, -velocity.z);
            	
            	
            

            	
            	
            	
            }
        }
            
        for ( SkeletonNode child : node.children ) {
            applyJointTorquesHelper( child );
        }
    }
    
    public void applySprings() {
    	for (MarionetteSpring s :springs) {
        	s.apply();
    	}
    }
    
    public void updateSprings() {
    	for (MarionetteSpring s :springs) {
        	s.updateSpringEnds();
    	}
    }
    
    /**
     * Displays the simulated skeleton
     * @param drawable
     */
    public void display( GLAutoDrawable drawable ) {
    	GL2 gl = drawable.getGL().getGL2();
    	for ( int i = 0; i < bodies.size(); i++ ) {
        	gl.glLoadName( i ); // for picking
            bodies.get(i).display( drawable);
        }
    }
    
    /** 
     * Displays the marionette springs as non shadowable transparent lines
     * @param drawable
     */
    public void displayMarrionetteSprings( GLAutoDrawable drawable ){
    	for ( MarionetteSpring s : springs ) {
        	s.display(drawable);
        }
    }
    
    /**
     * Resets the skeleton to its initial conditions
     */
    public void reset() {
        for ( BoxBodyODE b : bodies ) {
            b.reset();
        }
        for (MarionetteSpring s :springs) {
        	s.updateSpringEnds();
        }
    }
    
}
