package comp559.pdcontrol;

import javax.vecmath.Point3d;
import javax.vecmath.Vector2d;
import javax.vecmath.Vector3d;

import org.ode4j.math.DVector3;
import org.ode4j.math.DVector3C;

import com.jogamp.opengl.GL;
import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;

/**
 * Spring to connect an ODE body to its position recorded in a BVH frame
 * @author kry
 */
public class MarionetteSpring {
    
    /** Spring stiffness, sometimes written k_s in equations */
    public static double k;
    
    /** Spring damping (along spring direction), sometimes written k_d in equations */
    public static double c;
    
    /** Rest length of this spring in meters*/
    public static double l0 = 1;
    
    public static double slacknessRatio = 0.9;
        
    /** Skeleton node (with associated odeBody) to connect with this spring */
    SkeletonNode node;
    
    /** End of spring on skeleton node, actually rest length above (y direction) the skeleton node, in world coordinates */
    private Point3d skeletonPoint = new Point3d();
    
    /** End of spring on the body in world coordinates */
    private Point3d bodyPoint = new Point3d();
    
    /**
     * Creates a spring between an ODE body and its associated skeleton node
     * @param node skeleton node to connect with a spring
     * @param scale the scale of the BVH in the ODE world
     */
    public MarionetteSpring( SkeletonNode node ) {
		this.node = node;		
		updateSpringEnds();
    }
    
    /**
     * Updates the position of the ends of the spring
     */
    void updateSpringEnds() {
    	// let's use the geometryPosition of the node to drive the odeBody (i.e., their positions align)
    	node.Ewfromb.getBackingMatrix().transform( node.geometryPosition, skeletonPoint );
    	// want target point to be above the ODE body location
    	skeletonPoint.y += l0 - slacknessRatio;
    	// find the point on the odeBody for the other end of the spring  
    	ODETools.setVecmathFromODE( bodyPoint, node.odeBody.body.getPosition() );
    }
        
    /**
     * Applies the spring force by adding a force to the body
     */
    public void apply() {
    	// TODO: (Objective 5) Write code to apply marionette spring forces and damping
    	// Apply the force to the DBody, i.e., node.odeBody.body.addForce(f);
    	DVector3 f = new DVector3();
    	
    	Point3d p1 = new Point3d(skeletonPoint);
    	Point3d p2 = new Point3d(bodyPoint);
    	//skeleton body doesn't move
     	Vector3d vel1 = new Vector3d(node.v.get0(), node.v.get1(), node.v.get2());
     	DVector3C p = new DVector3(node.odeBody.body.getLinearVel());

    	Vector3d vel2 = new Vector3d(p.get0(), p.get1(), p.get2());
   
    	
    	
    	Vector3d displacement, velocity, spring_force;
    	double spring_force_scale;
    	
    	displacement = new Vector3d();
    	velocity = new Vector3d();
    	
    	displacement.sub(p1,  p2); //displacement from a to b
        velocity.sub(vel1,  vel2);
    	
    	spring_force_scale = 
    			- (k * (displacement.length() - l0) + 	c * (velocity.dot(displacement) / displacement.length())) 
    			/ displacement.length();
    	   	
    	spring_force = new Vector3d(displacement);	
    		
    	spring_force.scale(spring_force_scale);
    		
    	f.set(-spring_force.x, -spring_force.y, -spring_force.z);
    	
    	node.odeBody.body.addForce(f);
    	
    	
    	
    	
    }
    
    public void display(GLAutoDrawable drawable) {
    	GL2 gl = drawable.getGL().getGL2();
    	gl.glDisable( GL2.GL_LIGHTING );
    	gl.glColor4d( 0, 1, 0, 0.5 );
    	gl.glLineWidth(3);
        gl.glBegin(GL.GL_LINES);
        gl.glVertex3d(skeletonPoint.x, skeletonPoint.y, skeletonPoint.z);
        gl.glVertex3d(bodyPoint.x, bodyPoint.y, bodyPoint.z);
        gl.glEnd();
        gl.glEnable( GL2.GL_LIGHTING );
    }
}
