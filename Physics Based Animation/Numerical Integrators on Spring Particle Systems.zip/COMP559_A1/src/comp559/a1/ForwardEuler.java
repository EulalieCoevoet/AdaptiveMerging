package comp559.a1;

public class ForwardEuler implements Integrator {
    
    @Override
    public String getName() {
        return "Forward Euler";
    }
    
    /** 
     * Advances the system at t by h 
     * @param x The state at time h
     * @param n The dimension of the state (i.e., x.length)
     * @param t The current time (in case the derivs function is time dependent)
     * @param h The step size
     * @param xout  The state of the system at time t+h
     * @param derivs The object which computes the derivative of the system state
     */
    @Override
    public void step(double[] x, int n, double t, double h, double[] xout, Function derivs) {
        // TODO: Objective 3, implement the forward Euler method
    	double[] dxdt = new double[n];
        derivs.derivs(t, x, dxdt);
        //dxdt containts the derivatives. 
        //forward Euler:
        // x1 = x0 + hv0  --> can seperate into x and y directions
        //v1 = v0 + ha0
        for (int i = 0; i < n ; i ++) {
        	xout[i] = x[i] + h * x[i+2]; //x dir only
        	xout[i+1] = x[i + 1] + h * x[i + 3]; //y dir only
        	xout[i+2] = x[i + 2] + h * dxdt[i + 2]; //x dir only
        	xout[i+3] = x[i + 3] + h * dxdt[i + 3]; // y dir only
        	i +=3; 
        	
        }
    }

}
