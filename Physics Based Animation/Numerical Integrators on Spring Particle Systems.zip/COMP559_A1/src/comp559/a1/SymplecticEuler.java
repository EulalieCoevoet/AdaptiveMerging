package comp559.a1;

public class SymplecticEuler implements Integrator {

    @Override
    public String getName() {
        return "symplectic Euler";
    }

    @Override
    public void step(double[] x, int n, double t, double h, double[] xout, Function derivs) {
        // TODO: Objective 7, complete the symplectic Euler integration method.
    	// note you'll need to know how x is packed to properly implement this, so go
    	// look at ParticleSystem.getPhaseSpace()
    	 // TODO: Objective 4, implement midpoint method
    	double[] dx1dt = new double[n]; //new array
        derivs.derivs(t, x, dx1dt);
        double[] xnext = new double[n];
        //get halfstep... find position of midpoint. We will then find the gradient at that midpoint. 
        for(int i = 0; i < n; i ++) {
        	// velocity at the midpoint.
        	xout[i+2] = x[i + 2] + h* dx1dt[i + 2]; 
        	xout[i+3] = x[i + 3] + h * dx1dt[i + 3]; 
        	xout[i] = x[i] + h* xout[i+2]; //x dir only
        	xout[i+1] = x[i + 1] + h * xout[i + 3]; //y dir only
        	
        	i+=3;
        }
 
    }

}
