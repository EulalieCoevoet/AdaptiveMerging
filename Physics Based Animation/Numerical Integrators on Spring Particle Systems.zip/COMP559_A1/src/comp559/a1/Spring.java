package comp559.a1;

import javax.vecmath.Point2d;
import javax.vecmath.Vector2d;

import no.uib.cipr.matrix.Matrix;
import no.uib.cipr.matrix.Vector;

/**
 * Spring class for 599 assignment 1
 * @author kry
 */
public class Spring {

    Particle p1 = null;
    Particle p2 = null;
    
    /** Spring stiffness, sometimes written k_s in equations */
    public static double k = 1;
    /** Spring damping (along spring direction), sometimes written k_d in equations */
    public static double c = 1;
    /** Rest length of this spring */
    double l0 = 0;
    
    /**
     * Creates a spring between two particles
     * @param p1
     * @param p2
     */
    public Spring( Particle p1, Particle p2 ) {
        this.p1 = p1;
        this.p2 = p2;
        recomputeRestLength();
        p1.springs.add(this);
        p2.springs.add(this);
    }
    
    /**
     * Computes and sets the rest length based on the original position of the two particles 
     */
    public void recomputeRestLength() {
        l0 = p1.p0.distance( p2.p0 );
    }
    
    /**
     * Applies the spring force by adding a force to each particle
     */
    public void apply() {
        // TODO: Objective 1, FINISH THIS CODE!

    	
    	Vector2d displacement, velocity, spring_force;
    	double spring_force_scale;
    	
    	displacement = new Vector2d();
    	velocity = new Vector2d();
    	
    	displacement.sub(p1.p,  p2.p); //displacement from a to b
    	velocity.sub(p1.v,  p2.v);
    	
    	spring_force_scale = 
    			- (k * (displacement.length() - l0) + 	c * (velocity.dot(displacement) / displacement.length())) 
    			/ displacement.length();
    	   	
    	spring_force = new Vector2d(displacement);	
    		
    	spring_force.scale(spring_force_scale);
    		
    	//adding the forces
    	p1.addForce(spring_force);
    	spring_force.scale(-1);
    	p2.addForce(spring_force);
    	
    	
    	
    }
       
    /**
     * Computes the force and adds it to the appropriate components of the force vector.
     * (This function is something you might use for a backward Euler integrator)
     * @param f
     */
    public void addForce( Vector f ) {
        // TODO: Objective 8, FINISH THIS CODE for backward Euler method (probably very simlar to what you did above)
    	Vector2d displacement = new Vector2d(p2.p);
    	displacement.sub(p1.p);
    
    	//displacement now holds the displacement vector from p1 to p2
    	double distance = p2.p.distance(p1.p);
    	displacement.scale(1/distance);
    	//remembers a copy of the displacement.
    	//displacement now normalized.
        
    	double spring_force_scale = Spring.k * (distance/this.l0 - 1);
    	
    	displacement.scale(spring_force_scale);
    	Vector2d spring_force = new Vector2d(displacement);
    	
    	p1.addForce(spring_force);
    	spring_force.scale(-1);
    	p2.addForce(spring_force);
    	
        int p1_index = 2 * p1.index;
        int p2_index = 2 * p2.index;
        
        f.set(p1_index, p1.f.x);
        f.set(p1_index + 1, p1.f.y);
        f.set(p2_index, p2.f.x);
        f.set(p2_index + 1, p2.f.y);
        
        
        
    }
    
    /**
     * Adds this springs contribution to the stiffness matrix
     * @param dfdx
     */
    public void addDfdx( Matrix dfdx ) {
  
    
    	    // DONE: Objective 8, FINISH THIS CODE... necessary for backward euler integration
    		double[][] hessA;
    		int p1_index, p2_index;
    		
    		p1_index = 2 * p1.index;
    		
    		p2_index = 2 * p2.index;
    	
    		
    		
    		hessA = new double[4][4];
    		mapleComputation(hessA);
    		
    		// Setting f_p1 and p1
    	    dfdx.add(p1_index, p1_index, hessA[0][0]);
    	    dfdx.add(p1_index, p1_index + 1, hessA[0][1]);
    	    dfdx.add(p1_index + 1, p1_index, hessA[1][0]);
    	    dfdx.add(p1_index + 1, p1_index + 1, hessA[1][1]);

    		// Setting f_p1 and p2
    	    dfdx.add(p1_index, p2_index, hessA[0][2]);
    	    dfdx.add(p1_index, p2_index + 1, hessA[0][3]);
    	    dfdx.add(p1_index + 1, p2_index, hessA[1][2]);
    	    dfdx.add(p1_index + 1, p2_index + 1, hessA[1][3]);
    	    
    		// Setting f_p2 and p1
    	    dfdx.add(p2_index, p1_index, hessA[2][0]);
    	    dfdx.add(p2_index, p1_index + 1, hessA[2][1]);
    	    dfdx.add(p2_index + 1, p1_index, hessA[3][0]);
    	    dfdx.add(p2_index + 1, p1_index + 1, hessA[3][1]);
    	    
    		// Setting f_p2 and p2
    	    dfdx.add(p2_index, p2_index, hessA[2][2]);
    	    dfdx.add(p2_index, p2_index + 1, hessA[2][3]);
    	    dfdx.add(p2_index + 1, p2_index, hessA[3][2]);
    	    dfdx.add(p2_index + 1, p2_index + 1, hessA[3][3]);
    	 
    }   
    
    
    public void mapleComputation(double [][] HessA) {
    	/*
    	double Ax = p1.p.x;
    	double Bx = p2.p.x;
    	double Ay = p1.p.y;
    	double By = p2.p.y;
    	double t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12;
    	t1 = Bx * Bx - 2 * Bx * Ax + Ax * Ax + By * By - 2 * By * Ay + Ay * Ay;
    	t2 = -2 * Bx + 2 * Ax;
    	t3 = Math.pow(t1, -0.3e1 / 0.2e1);
    	t4 = (int)Math.pow((double) t1, (double) 2) * t3 - l0;
    	t5 = 1 / t1;
    	t1 = t4 * t1 * t3;
    	t3 = t5 / 4 - t4 * t3 / 4;
    	t4 = -2 * By + 2 * Ay;
    	t5 = t3 * k;
    	t6 = t5 * t2;
    	t7 = t6 * t4;
    	t8 = -t2;
    	t9 = k * (t3 * t8 * t2 - t1);
    	t10 = -t4;
    	t6 = t6 * t10;
    	t11 = t5 * t4 * t8;
    	t12 = k * (t3 * t10 * t4 - t1);
    	t5 = t5 * t8 * t10;
    	
    	HessA[0][0] = k * (t3 * (int)Math.pow((double) t2, (double) 2) + t1);
    	HessA[0][1] = t7;
    	HessA[0][2] = t9;
    	HessA[0][3] = t6;
    	HessA[1][0] = t7;
    	HessA[1][1] = k * (t3 * Math.pow(t4, 2) + t1);
    	HessA[1][2] = t11;
    	HessA[1][3] = t12;
    	HessA[2][0] = t9;
    	HessA[2][1] = t11;
    	HessA[2][2] = k * (t3 * (int)Math.pow((double) t8, (double) 2) + t1);
    	HessA[2][3] = t5;
    	HessA[3][0] = t6;
    	HessA[3][1] = t12;
    	HessA[3][2] = t5;
    	HessA[3][3] = k * (t3 * Math.pow(t10, 2) + t1);
    	
    	*/
    	double Ax = p1.p.x;
    	double Bx = p2.p.x;
    	double Ay = p1.p.y;
    	double By = p2.p.y;
    	
    	double Ay2 = Ay*Ay;
    	double Ax2 = Ax*Ax;
    	double Bx2 = Bx*Bx;
    	double By2 = By*By;
    	
    	double lx = (Ax - Bx);
    	double ly = (Ay - By);
    	double dA = (Ax - Ay);
    	double dB = (Bx - By);
    	
    	double powLength = Math.pow(lx*lx + ly * ly, 1.5 );
    	
    	
    	HessA[0][0] = - k/this.l0 + k * (Ay2 - 2* Ay*By + By2)/powLength;// (int)Math.pow((double) t2, (double) 2) + t1);
    	HessA[0][1] = - k * lx * ly/ powLength;
    	HessA[0][2] = - k * (Ay2 - 2 * Ay * By + By2)/powLength + k/this.l0;
    	HessA[0][3] = k * lx*ly/powLength;
    	HessA[1][0] = - k * lx * ly/powLength;
    	HessA[1][1] = - k /this.l0 + k*(Ax2 - 2*Ax*Bx + Bx2)/powLength;
    	HessA[1][2] = k * lx*ly/powLength;
    	HessA[1][3] = - k * (Ax2 - 2*Ax*Bx + Bx2)/powLength + k/this.l0;
    	HessA[2][0] = -HessA[0][0];
    	HessA[2][1] = -HessA[0][1];
    	HessA[2][2] = -HessA[0][2];
    	HessA[2][3] = -HessA[0][3];
    	HessA[3][0] = -HessA[1][0];
    	HessA[3][1] = -HessA[1][1];
    	HessA[3][2] = -HessA[1][2];
    	HessA[3][3] = -HessA[1][3];
    	
    }
    /**
     * Adds this springs damping contribution to the implicit damping matrix
     * @param dfdv
     */
    public void addDfdv( Matrix dfdv ) {
        // TODO: Objective 8, FINISH THIS CODE... necessary for backward euler integration
        
    } 
    
}
