package comp559.a1;

public class ModifiedMidpoint implements Integrator {

    @Override
    public String getName() {
        return "modified midpoint";
    }

    double[] tmp;
    
    @Override
    public void step(double[] x, int n, double t, double h, double[] xout, Function derivs) {

    	 // TODO: Objective 4, implement midpoint method
    	double[] dxdt = new double[n]; //new array
        derivs.derivs(t, x, dxdt);
        double[] xmid = new double[n];
        //get halfstep... find position of midpoint. We will then find the gradient at that midpoint. 
        for(int i = 0; i < n; i ++) {
        	xmid[i] = x[i] + h*0.667* x[i+2]; //x dir only
        	xmid[i+1] = x[i + 1] + h *0.667* x[i + 3]; //y dir only
        	// velocity at the midpoint.
        	xmid[i+2] = x[i + 2] + h*.667 * dxdt[i + 2]; //vx dir only at halfstep
        	xmid[i+3] = x[i + 3] + h *0.667* dxdt[i + 3]; // vy dir only at halfsetp
        	i+=3;
        }
        derivs.derivs(t, xmid, dxdt); //find the new velocity and acceleration at the midpoint.
        //run again, this time with the updated dxdt accelerations. 
        //the xmid velocities should remain the same after calling derivs.derivs
        for (int i = 0; i < n ; i ++) {
        	xout[i] = x[i] + h * xmid[i+2]; //x dir only
        	xout[i+1] = x[i + 1] + h * xmid[i + 3]; //y dir only
        	xout[i+2] = x[i + 2] + h * dxdt[i + 2]; //x dir only
        	xout[i+3] = x[i + 3] + h * dxdt[i + 3]; // y dir only
        	i +=3; 
        	
        }
    	// TODO: Objective 5, implmement the modified midpoint (2/3) method.

    }

}
