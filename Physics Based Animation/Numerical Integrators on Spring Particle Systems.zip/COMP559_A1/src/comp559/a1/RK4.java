package comp559.a1;

public class RK4 implements Integrator {
    
    @Override
    public String getName() {
        return "RK4";
    }

    @Override
    public void step(double[] x, int n, double t, double h, double[] xout, Function derivs) {
        // TODO: Objective 6, implement the RK4 integration method
    	 // TODO: Objective 4, implement midpoint method
    	double[] dk1dt = new double[n]; //new array
        derivs.derivs(t, x, dk1dt);
        double[] k1 = new double[n];
        //get halfstep... find position of midpoint. We will then find the gradient at that midpoint. 
        for(int i = 0; i < n; i ++) {
        	k1[i] = x[i] + h*0.5* x[i+2]; //x dir only
        	k1[i+1] = x[i + 1] + h *0.5* x[i + 3]; //y dir only
        	// velocity at the midpoint.
        	k1[i+2] = x[i + 2] + h*0.5 * dk1dt[i + 2]; //vx dir only at halfstep
        	k1[i+3] = x[i + 3] + h *0.5* dk1dt[i + 3]; // vy dir only at halfsetp
        	i+=3;
        }
        double[] dk2dt = new double[n]; 
        double[] k2 = new double[n];
        derivs.derivs(t, k1, dk2dt); 
        for (int i = 0; i < n ; i ++) {
        	k2[i] = x[i] + h * 0.5* k1[i+2]; //x dir only
        	k2[i+1] = x[i + 1] + h * 0.5* k1[i + 3]; //y dir only
        	k2[i+2] = x[i + 2] + h * 0.5*dk2dt[i + 2]; //x dir only
        	k2[i+3] = x[i + 3] + h * 0.5*dk2dt[i + 3]; // y dir only
        	i +=3; 	
        }
        double[] dk3dt = new double[n]; 
        double[] k3 = new double[n];
        derivs.derivs(t, k2, dk3dt); 
        for (int i = 0; i < n ; i ++) {
        	k3[i] = x[i] + h * 0.5*k2[i+2]; //x dir only
        	k3[i+1] = x[i + 1] + h*0.5* k2[i + 3]; //y dir only
        	k3[i+2] = x[i + 2] + h * 0.5*dk3dt[i + 2]; //x dir only
        	k3[i+3] = x[i + 3] + h *0.5* dk3dt[i + 3]; // y dir only
        	i +=3; 	
        }
        double[] dk4dt = new double[n]; 
        double[] k4 = new double[n];
        derivs.derivs(t, k3, dk4dt); 
        for (int i = 0; i < n ; i ++) {
        	k4[i] = x[i] + h * k3[i+2]; //x dir only
        	k4[i+1] = x[i + 1] + h * k3[i + 3]; //y dir only
        	k4[i+2] = x[i + 2] + h * dk4dt[i + 2]; //x dir only
        	k4[i+3] = x[i + 3] + h * dk4dt[i + 3]; // y dir only
        	i +=3; 	
        }
        // averaging all the ks
        for (int i = 0; i < n ; i ++) {
        	xout[i] = x[i] + h * 0.1667*( k1[i+2] + 2*k2[i+2] + 2 *k3[i+2] + k4[i+2]); //x dir only
        	xout[i+1] = x[i + 1] + h * 0.1667*( k1[i+3] + 2*k2[i+3] + 2 *k3[i+3] + k4[i+3]); //y dir only
        	xout[i+2] = x[i + 2] + h *0.1667* (dk1dt[i+2] + 2 * dk2dt[i+2] + 2 *dk3dt[i+2] + dk4dt[i+2]); //x dir only
        	xout[i+3] = x[i + 3] + h *0.1667* (dk1dt[i+3] + 2 * dk2dt[i+3] + 2 *dk3dt[i+3] + dk4dt[i+3]); // y dir only
        	i +=3; 	
        }
    }
    
}
