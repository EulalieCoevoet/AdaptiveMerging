package comp559.a1;

/**
 * Interface for a numerical integration method
 * 
 * Note that the state is stored in a variable called x, but other good variable names 
 * would have been y as seen in Numerical Recipies, or q as used in class for a system 
 * with changed variables or some other representation of state.  
 * 
 * 
 * x (state)
 * ^
 * |
 * | ,--._/ trajectory
 * |/
 * |
 * +-------> t (time)
 *
 * See the NR book online, chapter 17, for additional information on integration of ODEs:
 * http://www.nrbook.com/nr3/
 * 
 * @author kry
 */
public interface Integrator {

    /** 
     * @return the name of this numerical integration method
     */
    public String getName();
    
    /** 
     * Advances the system at t by h 
     * @param x The state at time h
     * @param n The dimension of the state (i.e., x.length)
     * @param t The current time (in case the derivs function is time dependent)
     * @param h The step size
     * @param xout  The state of the system at time t+h
     * @param derivs The object which computes the derivative of the system state
     */
    public void step(double[] x, int n, double t, double h, double[] xout, Function derivs); 
}
