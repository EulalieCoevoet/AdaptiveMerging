# -*- coding: utf-8 -*-
"""
Created on Tue Apr 16 22:22:23 2019

@author: otman
"""

import sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
import numpy as np
from sklearn.model_selection import cross_val_score
from scipy.sparse import load_npz
from sklearn.feature_selection import SelectPercentile, chi2
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.model_selection import cross_val_score
from sklearn.gaussian_process.kernels import RBF
from sklearn.naive_bayes import GaussianNB


y_train = np.load("y_train.npy")

X_train_non_lexicalized = np.load("X_train_non_lexicalized.npy")


X_train_premises = load_npz("X_train_unigrams_bigrams_premises.npz")
X_train_premises = SelectPercentile(chi2, percentile=1).fit_transform(X_train_premises, y_train)
X_train_premises = np.float16(X_train_premises.toarray())

X_train_unigrams_bigrams = load_npz("X_train_unigrams_bigrams.npz")
X_train_unigrams_bigrams = SelectPercentile(chi2, percentile=1).fit_transform(X_train_unigrams_bigrams, y_train)
X_train_unigrams_bigrams = np.float16(X_train_unigrams_bigrams.toarray())


X_train_cross_unigrams = load_npz("X_train_cross_unigrams.npz")
X_train_cross_unigrams  = SelectPercentile(chi2, percentile=0.05).fit_transform(X_train_cross_unigrams , y_train)
X_train_cross_unigrams  = np.float16(X_train_cross_unigrams.toarray())

X_train = np.append(X_train_non_lexicalized, X_train_unigrams_bigrams, axis=1)
X_train = np.append(X_train, X_train_cross_unigrams, axis=1)

logreg_classifier = LogisticRegression()
crossv_score_regression = cross_val_score(logreg_classifier, X_train[:200000], y_train[:200000], cv=3)

svm_classifier = LinearSVC()
crossv_score_svm = cross_val_score(svm_classifier, X_train[:200000], y_train[:200000], cv=3)

gnb_classifier = GaussianNB()
crossv_score_gnb = cross_val_score(gnb_classifier, X_train[:100000], y_train[:100000], cv=3)


print("logreg accuracy" + str(np.mean(crossv_score_regression)))
print("svm accuracy" + str(np.mean(crossv_score_svm)))
print("gnb accuracy" + str(np.mean(crossv_score_gnb)))



import keras
from keras.models import Sequential
from keras.layers import Dense
mlp = Sequential()
mlp.add(Dense(100, activation='relu'))
mlp.add(Dense(100, activation='relu'))
mlp.add(Dense(100, activation='relu'))
mlp.add(Dense(100, activation='relu'))
mlp.add(Dense(1))
mlp.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
mlp.fit(X_train, y_train, epochs = 2, validation_split=.1)

