# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 21:47:17 2019

@author: Sarah
"""
import csv
import textdistance
from nltk.tokenize import word_tokenize 
from nltk.corpus import stopwords
import nltk
from nltk.translate.bleu_score import sentence_bleu
import sklearn
from sklearn.metrics import accuracy_score, recall_score, precision_score
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import LinearSVC
from sklearn.feature_extraction.text import CountVectorizer
import keras
from keras.models import Sequential
from keras.layers import Dense, Conv1D, LSTM
from keras.layers.embeddings import Embedding
import collections
from collections import Counter
from scipy.sparse import save_npz

import gensim
from gensim.models.doc2vec import Doc2Vec, TaggedDocument

import numpy as np

class corpus_classifier:
    def __init__(self):
        return None
    
    def load_training_data(self):
        X_training = [None]*550152
        x_index = 0
        y_training = [None]*550152
        y_index = 0
        
        with open("./snli_1.0/snli_1.0_train.txt") as f:
            reader = csv.reader(f, delimiter="\t")
            d = list(reader)
        df = d[1:]
        
        #loads x training
        for arr in df:
            sentences = arr[5:7]
            X_training[x_index] = sentences
            x_index += 1
            
        #Loads y training
        for arr in df:
            element = arr[0]
            if(element != 'entailment'):
                y_training[y_index] = 0
                y_index += 1
            else:
                y_training[y_index] = 1
                y_index += 1
        
        return X_training, y_training
    
    def load_validation_data(self):
        X_val = [None]*10000
        x_index = 0
        y_val = [None]*10000
        y_index = 0
        
        with open("./snli_1.0/snli_1.0_dev.txt") as f:
            reader = csv.reader(f, delimiter="\t")
            d = list(reader)
        df = d[1:]
        
        #loads x validation
        for arr in df:
            sentences = arr[5:7]
            X_val[x_index] = sentences
            x_index += 1
            
        #Loads y validation
        for arr in df:
            element = arr[0]
            if(element != 'entailment'):
                y_val[y_index] = 0
                y_index += 1
            else:
                y_val[y_index] = 1
                y_index += 1
        
        return X_val, y_val
    
    def load_test_data(self):
        X_test = [None]*10000
        x_index = 0
        y_test = [None]*10000
        y_index = 0
        
        with open("./snli_1.0/snli_1.0_test.txt") as f:
            reader = csv.reader(f, delimiter="\t")
            d = list(reader)
        df = d[1:]
        
        #loads x test
        for arr in df:
            sentences = arr[5:7]
            X_test[x_index] = sentences
            x_index += 1
            
        #Loads y test
        for arr in df:
            element = arr[0]
            if(element != 'entailment'):
                y_test[y_index] = 0
                y_index += 1
            else:
                y_test[y_index] = 1
                y_index += 1
        
        return X_test, y_test
    
    def preprocess(self, x, size):
        stop_words = set(stopwords.words('english'))
        preprocessed1 = [None]*size
        pi = 0
        for pair in x:
            finalpair = [None]*2
            fi = 0
            for sentence in pair:
             #   print(sentence)
                sentence = sentence.lower()
                sentence = word_tokenize(sentence)
                sentence = [w for w in sentence if not w in stop_words]
                finalpair[fi] = sentence
                fi += 1
            preprocessed1[pi] = finalpair
            pi += 1
            
        preprocessed2 = [None]*size
        pi = 0
        for pair in preprocessed1:
            finalpair= [None]*2
            fi = 0
            for sentence in pair:
                final = ''
                for word in sentence:
                    if(word != '.'):
                        final += word
                        final += ' '
                    if(word == '.'):
                        final = final[:-1]
                finalpair[fi] = final
                fi += 1
            preprocessed2[pi] = finalpair
            pi += 1
        
        return preprocessed2
    
    def jaro_winkler_distance(self, x_train):
        x_dist = [None]*len(x_train)
        xd_index = 0
        for pair in x_train:
            dist = textdistance.jaro_winkler(pair[0], pair[1])
            x_dist[xd_index] = dist
            xd_index += 1

        return x_dist
    
    def levenshtein_distance(self, x_train):
        x_dist = [None]*len(x_train)
        xd_index = 0
        for pair in x_train:
            dist = textdistance.levenshtein.normalized_similarity(pair[0], pair[1])
            x_dist[xd_index] = dist
            xd_index += 1
        
        return x_dist
    
    def hamming_distance(self, x_train):
        
        x_dist = [None]*len(x_train)
        xd_index = 0
        for pair in x_train:
            dist = textdistance.hamming.normalized_similarity(pair[0], pair[1])
            x_dist[xd_index] = dist
            xd_index += 1
   
        return x_dist
    
    def non_lexicalized_score(self, x_train, overlap=False):
        """
        Includes bleu score, length difference score, as well as overlap. Takes a WHILE to run
        overlap is N by 4. [absolute overlap, percentage overlap, same for just nouns verbs adjectives and adverbs]
        """
        length_scores =  np.zeros([len(x_train), 1])
        bleu_scores = np.zeros([len(x_train), 1])
        overlap_scores = np.zeros([len(x_train), 4])
        
        index = 0
        for pair in x_train:
            print(index)
            pair_1 = word_tokenize(pair[0])
            pair_2 = word_tokenize(pair[1])
            bleu = sentence_bleu([pair_1], pair_2, weights=(1, 1, 0, 0))
            bleu_scores[index] = bleu
            length_difference = len(pair_1) - len(pair_2)
            length_scores[index] = length_difference
            if(overlap):
                    abs_score, rel_score = self.find_overlap(pair_1, pair_2)
                    tagged_pair_1 = nltk.pos_tag(pair_1)
                    tagged_pair_2 = nltk.pos_tag(pair_2)
                    filtered_pair_1 = [s for s in tagged_pair_1 if (s[1][:2] == 'NN' or s[1][:2] == 'JJ' or s[1][:2]=='RB' or s[1][:2]=='VB') ]
                    filtered_pair_2 = [s for s in tagged_pair_2 if (s[1][:2] == 'NN' or s[1][:2] == 'JJ' or s[1][:2]=='RB' or s[1][:2]=='VB') ]
                    abs_filtered_score, rel_filtered_score = self.find_overlap(filtered_pair_1, filtered_pair_2)
                    
                    overlap_scores[index] = np.array([abs_score, rel_score, abs_filtered_score, rel_filtered_score])
            index+=1
        bleu_scores = np.around(bleu_scores, 7)
        
        return bleu_scores, length_scores,overlap_scores

    def find_overlap(self, pair_1, pair_2):
        """
        finds absolute and relative overlap
        """
        
        maximum_similarities = len(pair_1)*len(pair_2)
        if(len(pair_1) ==0 or len(pair_2) ==0):
            maximum_similarities = 1
        similarities = 0
        for ref_word in pair_1:
            for check_word in pair_2:
                if ref_word==check_word:
                    similarities+=1
        relative_similarities = similarities/maximum_similarities
        return similarities, relative_similarities
            
    def build_sentence_embedding_model(self, x_train_final, model_name):
        data_2 = np.array(x_train_final).reshape(2*len(x_train_final))

        tagged_data = [TaggedDocument(words=word_tokenize(_d.lower()), tags=[str(i)]) for i, _d in enumerate(data_2)]

        max_epochs = 20
        vec_size = 100
        alpha = 0.025
        
        model = Doc2Vec(vector_size=vec_size,
                        alpha=alpha, 
                        min_alpha=0.00025,
                        min_count=1,
                        dm =1)
        model.build_vocab(tagged_data)
        for epoch in range(max_epochs):
            print('iteration {0}'.format(epoch))
            model.train(tagged_data,
                        total_examples=model.corpus_count,
                        epochs=1)
            # decrease the learning rate
            model.alpha -= 0.0002
            # fix the learning rate, no decay
        model.save(model_name + ".model")
        print("Model Saved")
        return model
    
    def embed_data(self, x_train, model):
        data = x_train
        embedded_x = np.zeros([len(data), 200])
        index = 0
        for pair in data:
            pair_1 = model.infer_vector([pair[0]])
            pair_2 = model.infer_vector([pair[1]])
            embedded_x[index, :100] = pair_1
            embedded_x[index, 100:] = pair_2
            index+=1
        return embedded_x
            
    def build_neural_classifier(self, x_train, y_train):
        data=x_train
        target = np.asarray(y_train).reshape(-1, 1)
        
        neural_classifier = Sequential()
        neural_classifier.add(Dense(200, activation='tanh'))
        neural_classifier.add(Dense(200, activation='tanh'))
        neural_classifier.add(Dense(200, activation='tanh'))
        neural_classifier.add(Dense(1, activation='softmax'))
        neural_classifier.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
        neural_classifier.fit(data, target, epochs=10 )
        
    def alternate_neural_classifier(self, x_train, y_train):
        #### get back to LSTMs
        data= x_train
        target = np.asarray(y_train).reshape(-1, 1)
        neural_classifier = Sequential()
        neural_classifier.add(LSTM(200, activation='tanh'))
        neural_classifier.add(LSTM(200, activation='tanh'))
        neural_classifier.add(LSTM(200, activation='tanh'))
        neural_classifier.add(Dense(1, activation='softmax'))
        neural_classifier.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
        neural_classifier.fit(data, target, epochs=10 )
    
    def unigrams_bigrams(self, x_train):
        data = np.array(x_train);
        sentences = data[:, 0]
        index = 0
        for sentence in sentences:
            sentence += " "
            sentence += data[index, 1]
            sentences[index] = sentence
            index+=1
        cv = CountVectorizer(ngram_range=[1, 2], max_features=40000)
        unigrams_bigrams = cv.fit(sentences)
        hypothesis = data[:, 1]
       
        premise = data[:, 0]
        premise = cv.transform(premise)
        hypothesis = cv.transform(hypothesis)
        return hypothesis, premise
    
    def cross_unigrams_vocabulary(self, x_train):
        data = x_train
    
      #  cross_unigrams=[None]*1000000000
        cross_uni = []
        string_x = [''] * len(x_train)

        index = 0
        for pair in data:
            pair_1 = nltk.word_tokenize(pair[0])
            pair_2 = nltk.word_tokenize(pair[1])
            tagged_pair_1 = nltk.pos_tag(pair_1)
            tagged_pair_2 = nltk.pos_tag(pair_2)
            for word_tuple_1 in tagged_pair_1:
                for word_tuple_2 in tagged_pair_2:
                    if word_tuple_1[1] == word_tuple_2[1]:
                        cross_unigram = word_tuple_1[0] + " " + word_tuple_2[0]
                        string_x[index] += cross_unigram + " "
                      
                     #   cross_unigrams[array_index] = cross_unigram
                        cross_uni.append(cross_unigram)
            print(index)
            index+=1
        vocabulary = Counter(cross_uni)
        from operator import itemgetter
        sort_vocab = sorted(vocabulary.items(), key=itemgetter(1), reverse=True)
        vocab = np.asarray(sort_vocab)
        vocab= vocab[:, 0]
        return vocab, string_x
    
    def get_cross_unigrams_vectorizer(self, string_x, vocabulary):
        data = string_x
        cv = CountVectorizer(ngram_range=[2, 2], vocabulary=vocabulary, max_features=10000)
        cv.fit(data)
        data = cv.transform(data)
        return data
    
    def test_cross_unigrams_vectorizer(self, x_train, vocabulary):
        ### build string_x
        data = x_train
    
      #  cross_unigrams=[None]*1000000000
        cross_uni = []
        string_x = [''] * len(x_train)

        index = 0
        for pair in data:
            pair_1 = nltk.word_tokenize(pair[0])
            pair_2 = nltk.word_tokenize(pair[1])
            tagged_pair_1 = nltk.pos_tag(pair_1)
            tagged_pair_2 = nltk.pos_tag(pair_2)
            for word_tuple_1 in tagged_pair_1:
                for word_tuple_2 in tagged_pair_2:
                    if word_tuple_1[1] == word_tuple_2[1]:
                        cross_unigram = word_tuple_1[0] + " " + word_tuple_2[0]
                        string_x[index] += cross_unigram + " "
            index+=1
        data = string_x
        cv = CountVectorizer(ngram_range=[2, 2], vocabulary=vocabulary)
        cv.fit(data)
        data = cv.transform(data)
        return data
       
            
#############################################################
        
NLI_classifier = corpus_classifier()
x_train, y_train = NLI_classifier.load_training_data()
x_val, y_val = NLI_classifier.load_validation_data()
x_test, y_test = NLI_classifier.load_test_data()

x_train_final = NLI_classifier.preprocess(x_train, 550152)
x_val_final = NLI_classifier.preprocess(x_val, 10000)
x_test_final = NLI_classifier.preprocess(x_test, 10000)


# Uncomment this block of code for edit_distance based classification

################ use jaro winkler KNN classifier part 1 classifier ######

X_train_JW_distance = np.array(NLI_classifier.jaro_winkler_distance(x_train_final)).reshape(-1, 1)
X_val_JW_distance = np.array(NLI_classifier.jaro_winkler_distance(x_val_final)).reshape(-1, 1)
X_test_JW_distance = np.array(NLI_classifier.jaro_winkler_distance(x_test_final)).reshape(-1, 1)

knn_classifier = LogisticRegression()
#uncomment this line to do cross validation
knn_JW_crossv_score = cross_val_score(knn_classifier, X_train_JW_distance.reshape(-1, 1), y_train)
knn_classifier = knn_classifier.fit(X_train_JW_distance.reshape(-1, 1), y_train)
score = knn_classifier.score(X_val_JW_distance.reshape(-1, 1), y_val)

#
#
#
################### use levenshtein distance KNN classifier for part 1 #########
X_train_LV_distance = np.array(NLI_classifier.levenshtein_distance(x_train_final)).reshape(-1, 1)
X_val_LV_distance = np.array(NLI_classifier.levenshtein_distance(x_val_final)).reshape(-1, 1)
X_test_LV_distance = np.array(NLI_classifier.levenshtein_distance(x_test_final)).reshape(-1, 1)

#uncomment this line to do cross validation
knn_classifier = LogisticRegression()
#uncomment this line to do cross validation
knn_LV_crossv_score = cross_val_score(knn_classifier, X_train_LV_distance.reshape(-1, 1), y_train)
knn_classifier = knn_classifier.fit(X_train_LV_distance, y_train)
#score = knn_classifier.score(X_val_LV_distance.reshape, y_val)
#
#
#
#
############## use hamming distance KNN classifier for part 1 #########
#X_train_hamming_distance = np.array(NLI_classifier.hamming_distance(x_train_final)).reshape(-1, 1)
#X_val_hamming_distance = np.array(NLI_classifier.hamming_distance(x_val_final)).reshape(-1, 1)
#X_test_hamming_distance = np.array(NLI_classifier.hamming_distance(x_test_final)).reshape(-1, 1)
#
#knn_classifier = KNeighborsClassifier(n_neighbors=100)
##uncomment this line to do cross validation
#knn_HM_crossv_score = cross_val_score(knn_classifier, X_train_hamming_distance.reshape(-1, 1), y_train)
#knn_classifier = knn_classifier.fit(X_train_LV_distance, y_train)
##score = knn_classifier.score(X_val_HM_distance.reshape, y_val)
#
#
#
#
########### combine hamming, LV, and JW distances #################################
#X_combined_train = np.float16(X_train_hamming_distance) + np.float16(X_train_LV_distance) + np.float16(X_train_JW_distance.reshape(-1,1))
#knn_classifier = KNeighborsClassifier(n_neighbors=100)
##uncomment this line to do cross validation
#knn_combined_crossv_score = cross_val_score(knn_classifier, X_combined_train, y_train)





################  Non-Lexicalized Classifier ######################################

X_train_bleu, X_train_length, X_train_overlap = NLI_classifier.non_lexicalized_score(x_train_final, True)
X_val_bleu, X_val_length, X_val_overlap = NLI_classifier.non_lexicalized_score(x_val_final, True)
X_test_bleu, X_test_length, X_test_overlap = NLI_classifier.non_lexicalized_score(x_test_final, True)

X_train_non_lexicalized = np.append(X_train_bleu, X_train_length, axis=1)
X_train_non_lexicalized = np.append(X_train_non_lexicalized, X_train_overlap, axis=1)

np.save("X_train_non_lexicalized", X_train_non_lexicalized)
np.save("y_train", y_train)
# build logreg  classifier
logreg_classifier = LogisticRegression();
logreg_nonLex_score = cross_val_score(logreg_classifier, X_train_non_lexicalized, y_train)

#build svm classifier
svm_classifier = LinearSVC();
svm_nonLex_score = cross_val_score(svm_classifier, X_train_non_lexicalized, y_train)


#Need to do count vectorizer, cross bi grams, cross uni_grams
#append count vectorizer
X_train_unigrams_bigrams, premises = NLI_classifier.unigrams_bigrams(x_train_final)
save_npz("X_train_unigrams_bigrams", X_train_unigrams_bigrams)
save_npz("X_train_unigrams_bigrams_premises", premises)
#### change this to val
vocabulary, string_x = NLI_classifier.cross_unigrams_vocabulary(x_train_final)
X_train_cross_unigrams = NLI_classifier.get_cross_unigrams_vectorizer(string_x, vocabulary)
save_npz("X_train_cross_unigrams.npz", X_train_cross_unigrams)

X_val_cross_unigrams = NLI_classifier.test_cross_unigrams_vectorizer(x_val_final, vocabulary)
X_test_cross_unigrams = NLI_classifier.test_cross_unigrams_vectorizer(x_test_final, vocabulary)

X_train_lexicalized = np.append(X_train_non_lexicalized[:100000], X_train_cross_unigrams[:100000, :2000].toarray(), axis=1)

logreg_classifier = LogisticRegression();
logreg_lex_score = cross_val_score(logreg_classifier, X_train_non_lexicalized, y_train)

################ Sentence Embeddings with LSTM Model #################################

#if model isn't determined yet, or no model in directory, uncomment this line and train model
#model = NLI_classifier.build_sentence_embedding_model(x_train_final, "model")
#load model from directory
model= Doc2Vec.load("d2v.model")
for epoch in range(max_epochs):
    print('iteration {0}'.format(epoch))
    model.train(tagged_data,
                total_examples=model.corpus_count,
                epochs=1)
    # decrease the learning rate
    model.alpha -= 0.0002
X_train_LSTM = NLI_classifier.embed_data(x_train_final, model)
X_val_LSTM = NLI_classifier.embed_data(x_val_final, model)
X_test_LSTM = NLI_classifier.embed_data(x_test_final, model)