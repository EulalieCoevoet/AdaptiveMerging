import os
import collections
import sklearn
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.utils import shuffle
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn import tree
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import cross_val_score



class imdb_sentiment_analysis:
    def __init__(self):
        #training folder must be in the same directory as this script
        self.negative_folder = "./train/neg/"
        self.positive_folder = "./train/pos/"
        self.test_folder = "./test/"
    
    def load_train_data(self, negative_folder, positive_folder):
        """
        loads both the positive and negative raw text for each instance,  and returns a list of string reviews X, with its corresponding
        target y vector
        
            Input:
                directory_negative: folder that contains all the negative IMDB reviews
                directory_positive: folder that contains all the positive IMDB reviews
            Output:
                X: a list containing strings of all the reviews
                y: a list containing info on whether that review was positive(1) or negative(0)
        """
        #loop through negative data
        negative_data = []
        negative_y = []
        
        for filename in os.listdir(negative_folder):
            with open(negative_folder + filename, encoding='utf8') as f:
                review = f.read()
                negative_data.append(review)
                negative_y.append(0)
            
        #loop through positive data
        positive_data = []
        positive_y = []
        for filename in os.listdir(positive_folder):
            with open(positive_folder + filename, encoding='utf8') as f:
                review = f.read()
                positive_data.append(review)
                positive_y.append(1)
            
            
        X = negative_data + positive_data
        y = negative_y + positive_y
        
        return X, y
    
    def load_test_data(self, test_folder):
        #loop through negative data
        test_data = []
        
        for i in range(len(os.listdir(test_folder))):
            with open(test_folder + str(i) + ".txt", encoding='utf8') as f:
                review = f.read()
                test_data.append(review)

        return test_data
    
    def preprocess(self, raw_X, y, *, binary_tri_grams=False, binary_bi_grams=False, binary_text_features=False, bi_grams=False, tri_grams=False, multi_text_features=False, tf_idf=False, num_features=10, num_bi_grams=10, vector=False, num_tri_grams=10):
        
        """
        Preprocess X and y. First, starts by shuffling the data, lowercasing it, tokenizing it, then based on the other optional keyword arguments, does something else.
            Input:
                raw_X : Array of strings representing each review
                y : corresponding target data for X. 0 if the corresponding X instance is negative, 1 if positive.
                
                kwargs:
                    binary_text_features: boolean to append binary occurences to X
                    multi_text_features: boolean to append multiple text occurences to X
                    bi_grams: boolean to append bi gram features to X. these are not binary
                    tri_grams: boolean to append tri gram features to X. these are not binary.
                    tf_idf: boolean that determines whether or not we apply tf_idf weighting to all features in X: bigrams, tri grams, word occurences etc. 
                    
                    TODO: look more into filtering out "That is" "We are" bad bi grams etc. TF_IDF takes care of this partially
                    
                other arguments are booleans. Add info as you implement them. Ultimately they should all append data to 
            Output:
                X : npumpy list array of words
                
                y: target data
        """

        X = np.zeros([len(raw_X), 0])
        if (binary_text_features):

           num_binary_text_features =   num_features
           vectorizer = CountVectorizer(max_features=num_binary_text_features, binary=True, stop_words=None)
           binary_text_features = vectorizer.fit_transform(raw_X).toarray()
           X = np.append(X, binary_text_features, axis=1)
           
        if (multi_text_features):

           num_multi_text_features = num_features
           vectorizer = CountVectorizer(max_features=num_multi_text_features, stop_words=None)
           multi_text_features = vectorizer.fit_transform(raw_X).toarray()
           X = np.append(X, multi_text_features, axis=1)
        
        if (bi_grams):
           num_bi_grams_features = num_bi_grams
           vectorizer = CountVectorizer(ngram_range=(2, 2) , max_features=num_bi_grams_features, stop_words=None)
           bi_gram_features = vectorizer.fit_transform(raw_X).toarray()
           X = np.append(X, bi_gram_features, axis=1)
           
        if (binary_bi_grams):
           num_bi_grams_features = num_bi_grams
           vectorizer = CountVectorizer(ngram_range=(2, 2) , max_features=num_bi_grams_features, binary=True, stop_words=None)
           bi_gram_features = vectorizer.fit_transform(raw_X).toarray()
           X = np.append(X, bi_gram_features, axis=1)
       
        if (tri_grams):
           num_bi_grams_features = num_tri_grams
           vectorizer = CountVectorizer(ngram_range=(3, 3) , max_features=num_bi_grams_features, stop_words=None)
           tri_gram_features = vectorizer.fit_transform(raw_X).toarray()
           X = np.append(X, tri_gram_features, axis=1)
           
        if (binary_tri_grams):
          num_bi_grams_features = num_tri_grams
          vectorizer = CountVectorizer(ngram_range=(3, 3) , max_features=num_bi_grams_features, binary=True, stop_words=None)
          tri_gram_features = vectorizer.fit_transform(raw_X).toarray()
          X = np.append(X, tri_gram_features, axis=1)

           
        if(tf_idf):
             transformer = TfidfTransformer(smooth_idf=False)
             tfidf_terms = transformer.fit_transform(X).toarray()
             X = tfidf_terms
        y = np.asarray(y)
        
        if (vector):
             from keras.preprocessing.text import Tokenizer
             print("LSTM pre-preocessing...")
             tokenizer = Tokenizer(num_words=num_features)
            
             tokenizer.fit_on_texts(all_X)
             
        
             X = tokenizer.texts_to_sequences(raw_X)
             from keras.preprocessing import sequence
          #   max_words = 2525
             X = sequence.pad_sequences(X[:], padding='post')
           
            
     #   X = np.array(X)  
        y_train = y
        raw_X_train = raw_X[:25000]
        X_train = X[:25000]
        X_test = X[25000:]
        if not vector:
            X_train, y_train, raw_X_train = shuffle(X_train, y_train, raw_X_train )  
        return X_train, y_train, X_test, raw_X_train
        
        

   
    def naive_bayes_training(self, X, y):
       
        #basic probability
        
        y_pos = np.count_nonzero(y);
        y_neg = len(y) - y_pos
        
        theta_pos = y_pos/len(y);
        
        
        y_new  = np.array(y,ndmin=2);
        y_new = np.transpose(y_new);
        new_X = np.append(y_new,X,axis=1); #first column is y, followed by x
        X_size = np.shape(new_X);
        
        pos_review = np.empty(X_size,dtype=bool);
        neg_review = np.empty(X_size,dtype=bool);
        count = np.empty([2,X_size[1]-1], dtype =int);
        conditional = np.empty([2,X_size[1]-1], dtype =float);

        
        #calculation of all conditional probability
        for k in range(0,X_size[1]-1):
            for j in range(0,X_size[0]):
            
                pos_review[j,k] = new_X[j,0]==1 and new_X[j,k+1]==1; # true if y=1 given xk=1
                neg_review[j,k] = new_X[j,0]==0 and new_X[j,k+1]==1; # true if y=0 given xk=1
            
            count[0,k] = (pos_review[:,k]==True).sum();  #positive reviews with xk=1
            count[1,k] = (neg_review[:,k]==True).sum();  #negative reviews with xk=1
            conditional[0,k]=(count[0,k]+1)/(y_pos+2); #prob of y=1 given xk=1
            conditional[1,k]=(count[1,k]+1)/(y_pos+2); #prob of y=0 given xk=1
            



        return theta_pos,conditional

    

    def _decision_tree_model(self, X, y ):
        decision_tree_classifier = tree.DecisionTreeClassifier()
        decision_tree_classifier = decision_tree_classifier.fit(X, y)
        return decision_tree_classifier


    def naive_bayes_prediction(self, X, theta_pos, conditional):
        """
        
        """
        prediction_arr = []
        for input_review in X:
            bias = np.log10(theta_pos/(1-theta_pos)) ;
            summing =0;
            for j in range(0, np.size(input_review)):
                summing = summing + ((input_review[j]*np.log10(conditional[0,j]/conditional[1,j])) + (1-input_review[j])*np.log10((1-conditional[0,j])/(1-conditional[1,j])));
            summing += bias
            if summing > 0:
                prediction = 1
            else:
                prediction = 0;
            prediction_arr.append(prediction)
            
        prediction_arr = np.asarray(prediction_arr)
        return prediction_arr
        

    
    def support_vector_machine(self,X,y):


        from sklearn.svm import LinearSVC;
        clf = LinearSVC(C=1.0);

#        clf =SVC(C=1.0, cache_size=200, class_weight=None, coef0=0.0,
#                 decision_function_shape='ovo',  gamma='auto', kernel='linear',
#                 max_iter=-1, probability=False, random_state=None, shrinking=True,
#                 tol=0.001, verbose=False);

        clf.fit(X,y);
        return clf
    
    def multiVar_NB(self, X, y):
        from sklearn.naive_bayes import MultinomialNB
        classifier = MultinomialNB()
        classifier = classifier.fit(X, y)
        return classifier
    
    
    def _logistic_regression_model(self, X, y):
        logreg = LogisticRegression(C=1.0,max_iter=1000,multi_class='ovr',n_jobs=1,penalty='l2',random_state=None,solver='liblinear',tol=0.0001,verbose=1)
        logreg.fit(X, y)
        return logreg

    def run_standard_classification(self, X, y, validation_split=0.2, *, naive_bayes=False, decision_tree=False, logistic_regression=False, svm=False):
        """
           if running naive bayes, make sure you only have binary features. 
        """
        train_ratio = 1 - validation_split
        X_train = X[0:int(len(X)*train_ratio)]
        y_train = y[0:int(len(X)*train_ratio)]
        X_val = X[int(len(X)*train_ratio):]
        y_val = y[int(len(X)*train_ratio):]
        
        if decision_tree :
            classifier = self._decision_tree_model(X_train, y_train) 
            y_val_pred = classifier.predict_proba(X_val)[:,1]
            acc = accuracy_score(y_val, y_val_pred)
            print("Accuracy on decision tree: " + str(acc))
            
        if naive_bayes: 
            theta_pos, conditional= imdb.naive_bayes_training(X_train, y_train)
            y_val_pred = imdb.naive_bayes_prediction(X_val, theta_pos, conditional)
            acc = accuracy_score(y_val, y_val_pred)
            print("Accuracy on naive bayes: " + str(acc))
            
        if logistic_regression:
            model = imdb._logistic_regression_model(X_train, y_train)
            y_val_pred = model.predict(X_val)
            acc = accuracy_score(y_val, y_val_pred)
            print("Accuracy on logistic regression : " + str(acc))

        
        if svm:
            classifier = imdb.support_vector_machine(X_train, y_train)
            y_val_pred = classifier.predict(X_val)
            y_train_pred = classifier.predict(X_train)
            acc_train = accuracy_score(y_train,y_train_pred)
            acc = accuracy_score(y_val, y_val_pred)
            print("Accuracy on train: " + str(acc_train))
            print("Accuracy on SVM : " + str(acc))
                
    
    def neural_1DCNN(self, X_train, y, word_embeddings):
        from keras import Sequential
        from keras.layers import Embedding, LSTM, Dense, Dropout, Conv1D, Input, Flatten, MaxPooling1D
        from keras.callbacks import EarlyStopping, ModelCheckpoint

        
        embedding_size=16
        model=Sequential()
      
        model.add(Embedding(word_embeddings+1, embedding_size, input_length=X_train.shape[1]))

        model.add(Conv1D(100, 5, padding='causal'))
        
        
        model.add(Dropout(0.2))
        model.add(Conv1D(50, 3, padding='causal'))
        
        
        
        model.add(Flatten())
        model.add(Dense(64, activation='relu'))
        model.add(Dropout(0.2))
        #model.add(Dropout(0.5))
        model.add(Dense(1, activation='sigmoid'))
        print(model.summary())
        model.compile(loss='binary_crossentropy', 
                  optimizer='adam', 
                 metrics=['accuracy'])
        callbacks = [EarlyStopping(monitor='val_loss', patience=2),
                 ModelCheckpoint(filepath='best_model.h5', monitor='val_acc', save_best_only=True)]
        model.fit(X_train, y, validation_split=0.1, batch_size=32, epochs=10, callbacks=callbacks)
        return model
    
    def neural_1DCNN_2(self, X_train, y, word_embeddings):
        from keras import Sequential
        from keras.layers import Embedding, LSTM, Dense, Dropout, Conv1D, Input, Flatten, MaxPooling1D
        from keras.callbacks import EarlyStopping, ModelCheckpoint

        
        embedding_size=16
        model=Sequential()
      
        model.add(Embedding(word_embeddings+1, embedding_size, input_length=X_train.shape[1]))
        
        model.add(Conv1D(200, 10))
        model.add(Dropout(0.2))
        model.add(Conv1D(200, 7))
        model.add(Dropout(0.2))
        model.add(Conv1D(100, 5))
        model.add(Dropout(0.2))
        model.add(Conv1D(50, 3))
        
        
        
        model.add(Flatten())
        model.add(Dense(128, activation='relu'))
        model.add(Dense(64, activation='relu'))
        model.add(Dropout(0.2))
        #model.add(Dropout(0.5))
        model.add(Dense(1, activation='sigmoid'))
        print(model.summary())
        model.compile(loss='binary_crossentropy', 
                  optimizer='adam', 
                 metrics=['accuracy'])
        callbacks = [EarlyStopping(monitor='val_loss', patience=3),
                 ModelCheckpoint(filepath='test_model.h5', monitor='val_acc', save_best_only=True)]
        model.fit(X_train, y, validation_split=0.1, batch_size=32, epochs=10, callbacks=callbacks)
        return model
    
    def neural_LSTM(self, X_train, y, word_embeddings):
        from keras import Sequential
        from keras.layers import Embedding, LSTM, Dense, Dropout, Conv1D, Input, Flatten, MaxPooling1D
        from keras.callbacks import EarlyStopping, ModelCheckpoint
        embedding_size=32
        model=Sequential()
        model.add(Embedding(word_embeddings+1, embedding_size, input_length=X_train.shape[1]))
        model.add(LSTM(100))

        model.add(Dense(1, activation='sigmoid'))
        print(model.summary())
        model.compile(loss='binary_crossentropy', 
                  optimizer='adam', 
                 metrics=['accuracy'])
        callbacks = [EarlyStopping(monitor='val_loss', patience=2),
                 ModelCheckpoint(filepath='best_model.h5', monitor='val_acc', save_best_only=True)]
        model.fit(x_train, y, validation_split=0.1, batch_size=32, epochs=10, callbacks=callbacks)
        return model
    
    def run_k_fold_crossvalidation_classification(self, X, y, naive_bayes=False, decision_tree=False, logistic_regression=False, svm=False, num_folds=5):
       
       seg_length = int(len(X)/num_folds)      
       tempX = np.copy(X)
       tempy = np.copy(y)
       
       total_valid_accuracy=0
       total_train_accuracy=0
       for i in range(num_folds):
           X_val = X[(i) * seg_length: (i+1)*seg_length]
           y_val = y[(i) * seg_length: (i+1)*seg_length]
           X_train = np.delete(tempX, [range((i) * seg_length,  (i+1)*seg_length)], axis=0)
           y_train = np.delete(tempy, [range((i) * seg_length,  (i+1)*seg_length)], axis=0)
           
           if decision_tree :
               classifier = self._decision_tree_model(X_train, y_train) 
               y_val_pred = classifier.predict_proba(X_val)[:,1]
               y_train_pred = classifier.predict_proba(X_train)[:,1]
               valid_acc = accuracy_score(y_val, y_val_pred)
               train_acc = accuracy_score(y_train, y_train_pred)
               total_valid_accuracy += valid_acc
               total_train_accuracy += train_acc
               print("fold -" +str(i+1) +"- Train accuracy: " + str(train_acc))
               print("fold -" +str(i+1) +"- Valid accuracy: " + str(valid_acc))
            
           if naive_bayes: 
               theta_pos, conditional= self.naive_bayes_training(X_train, y_train)
               y_val_pred = self.naive_bayes_prediction(X_val, theta_pos, conditional)
               y_train_pred = self.naive_bayes_prediction(X_train, theta_pos, conditional)
               
               valid_acc = accuracy_score(y_val, y_val_pred)
               train_acc = accuracy_score(y_train, y_train_pred)
               total_valid_accuracy+= valid_acc
               total_train_accuracy+= train_acc

               print("fold -" +str(i+1) +"- Train accuracy: " + str(train_acc))
               print("fold -" +str(i+1) +"- Valid accuracy: " + str(valid_acc))
           
           if logistic_regression:
               classifier = self._logistic_regression_model(X_train, y_train)
               y_val_pred = classifier.predict(X_val)
               y_train_pred = classifier.predict(X_train)
               valid_acc = accuracy_score(y_val, y_val_pred)
               train_acc = accuracy_score(y_train, y_train_pred)
               total_valid_accuracy+= valid_acc
               total_train_accuracy+= train_acc

               print("fold -" +str(i+1) +"- Train accuracy: " + str(train_acc))
               print("fold -" +str(i+1) +"- Valid accuracy: " + str(valid_acc))
           if svm:
               classifier = self.support_vector_machine(X_train, y_train)
               y_val_pred = classifier.predict(X_val)
               y_train_pred = classifier.predict(X_train)
               valid_acc = accuracy_score(y_val, y_val_pred)
               train_acc = accuracy_score(y_train, y_train_pred)
               total_valid_accuracy+=valid_acc
               total_train_accuracy+=train_acc

               print("fold -" +str(i+1) +"- Train accuracy: " + str(train_acc))
               print("fold -" +str(i+1) +"- Valid accuracy: " + str(valid_acc))

       total_train_accuracy /= (num_folds)
       total_valid_accuracy /= (num_folds)
       print("Final train accuracy tree: " + str(total_train_accuracy))
       print("Final valid accuracy tree: " + str(total_valid_accuracy))
       
#imdb = imdb_sentiment_analysis()
#
#raw_X_train, y_train= imdb.load_train_data(imdb.negative_folder, imdb.positive_folder)
#raw_X_test = imdb.load_test_data(imdb.test_folder)
#
##first 25000 are for training
#all_X = raw_X_train + raw_X_test
#
#
##Bag of words preprocessing
#x_train_BOW, y_BOW, x_test_BOW, shuffled_raw_X_train = imdb.preprocess(all_X, y_train, binary_text_features=True , num_features=1000)
#
#x_train_BOW, x_val_BOW = [x_train_BOW[:20000], x_train_BOW[20000:]]
#y_train_BOW, y_val_BOW = [y_BOW[:20000], y_BOW[20000:]]
#
#x_tr = x_train_BOW
#x_v = x_val_BOW
#x_te = x_test_BOW
#
#x_train_BOW = x_tr
#x_val_BOW = x_v
#x_test_BOW = x_te
#
#from sklearn.feature_selection import SelectPercentile, chi2, f_classif, mutual_info_classif
#features = SelectPercentile(chi2, percentile=36)
#x_train_BOW = features.fit_transform(x_train_BOW, y_train_BOW)
#x_val_BOW = features.transform(x_val_BOW)
#x_test_BOW = features.transform(x_test_BOW)
#
#multi_bayes_classifier = imdb.multiVar_NB(x_train_BOW, y_BOW)
##y_pred_bayes = multi_bayes_classifier.predict_proba(x_val_BOW)[:, 1]
##y_pred_bayes_class = multi_bayes_classifier.predict(x_val_BOW)
##acc_bayes = accuracy_score(y_pred_bayes_class, y_val_BOW)
#score_mnb = cross_val_score(multi_bayes_classifier, x_train_BOW, y_BOW, cv=5, scoring='accuracy')
#
#from sklearn.naive_bayes import BernoulliNB
#classifier = BernoulliNB()
#classifier = classifier.fit(x_train_BOW, y_BOW)
#score_bnb = cross_val_score(classifier, x_train_BOW, y_BOW, cv=5, scoring='accuracy')
#
#
#logreg_classifier = imdb._logistic_regression_model(x_train_BOW, y_BOW)
#y_pred_logreg = logreg_classifier.predict_proba(x_val_BOW)[:,1 ]
#y_pred_logreg_class = logreg_classifier.predict(x_val_BOW)
#acc_logreg = accuracy_score(y_pred_logreg_class, y_val_BOW)
#score_logreg_f = cross_val_score(logreg_classifier, x_train_BOW, y_BOW, cv=5, scoring='accuracy')
#
#svm_classifier = imdb.support_vector_machine(x_train_BOW, y_BOW)
#y_pred_svm = svm_classifier.predict(x_val_BOW)
#acc_svm = accuracy_score(y_pred_svm, y_val_BOW)
#score_svm_1 = cross_val_score(svm_classifier, x_train_BOW, y_BOW, cv=5, scoring='accuracy')
#
#rand_forest_classifier=RandomForestClassifier(n_estimators=50)
#rand_forest_classifier = rand_forest_classifier.fit(x_train_BOW, y_train_BOW)
#y_pred_rand_forest =rand_forest_classifier.predict_proba(x_val_BOW)[:, 1]
#y_pred_rand_forest_class =rand_forest_classifier.predict(x_val_BOW)
#acc_rand = accuracy_score(y_pred_rand_forest_class, y_val_BOW)
#score_rand_for = cross_val_score(rand_forest_classifier, x_train_BOW, y_BOW, cv=5, scoring='accuracy')
##
#from sklearn.ensemble import VotingClassifier
#ensemble_clf = VotingClassifier([('lr', logreg_classifier), ('svm',svm_classifier), ('nb', multi_bayes_classifier)], voting='hard', weights=[1, 3, 1])
#
#
#score_ensemble_1_3_1 = cross_val_score(ensemble_clf, x_train_BOW, y_train_BOW, cv=5, scoring='accuracy')
#x_feed = np.append(x_train_BOW, x_val_BOW, axis=0)
#y_feed = np.append(y_train_BOW, y_val_BOW, axis=0)
##x_train_BOW = x_feed
##y_train_BOW = y_feed
#svm_classifier = svm_classifier.fit(x_feed, y_feed)
#y_pred = (y_pred_bayes + y_pred_logreg)/2
#y_pred_2 = [1 if i >0.5 else 0 for i in y_pred]
#
#
#
##Vector preprocessing for neural network 
#all_X=shuffled_raw_X_train + raw_X_test
#x_train_vec, y_vec, x_test_vec, shuffled_raw_X_train = imdb.preprocess(all_X, y_BOW, vector=True, num_features=10000)
#
#x_train_vec, x_val_vec = [x_train_vec[:20000], x_train_vec[20000:]]
#y_train_vec, y_val_vec = [y_vec[:20000], y_vec[20000:]]
#
#from keras.models import load_model
#
#neural_classifier = load_model("model_10000_feats_89acc.h5")
#print(neural_classifier.summary())
#x_val_vec = x_val_vec[:, :2120]
#from keras.preprocessing import sequence
#x_val_vec = sequence.pad_sequences(x_val_vec, 2209)
#y_pred_1 = neural_classifier.predict_classes(x_val_vec)
#acc_1 = accuracy_score(y_val_vec, y_pred_1)
##
#
#
#neural_classifier = imdb.neural_1DCNN_2(x_train_vec, y_train_vec, 100000 )
#
#acc_total = accuracy_score(y_val_vec, y_pred_2)
#classifier = imdb.run_standard_classification(x_train_BOW, y_BOW, naive_bayes=True)
#test_x =np.copy(x_test)
#y_test_pred = svm_classifier.predict(x_test_BOW)
#datafram = pd.DataFrame( y_test_pred)
#datafram.to_csv("final_submission.csv")
#acc_test = accuracy_score(y, y_pred)
#
#
##

